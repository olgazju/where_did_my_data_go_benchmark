# Benchmark v0.2 — Design Specification

**Status:** design only. No code, no API calls. This document delivers the scenario
matrix, evidence rules, expected labels, evaluation methodology, and implementation
sequence for review **before** any implementation.

**Central question (v0.2):** *Do the evidence-grounding improvements observed in
Experiment 03 (unsupported-positive rate 14.3% → 0%, correct-abstention 85.7% → 100%,
no over-abstention) generalize to previously unseen scenarios?* This is a **generalization
test**, not a prompt-optimization exercise. We measure whether the **frozen** P1/P2
conditions still suppress unsupported positives without inducing over-abstention on records
the intervention was never written against.

**Non-goals.** We are not tuning prompts to maximize accuracy on the POC. We are not
expanding the observability model, the label set, or the provider surface. We reuse the
existing `models` / `simulator` / `observability` / `solver` / `evaluator` / `baselines`
architecture unchanged except where this spec calls out a specific, minimal extension.

---

## 0. What is frozen, and what "frozen" means here

The three prompt conditions are frozen as **`prompts/frozen_v1/`** (hash-verified against
Experiment 03; see that directory's `manifest.json`). The frozen unit is each condition's
**delta over the shared task template**:

- **P0** — no delta (baseline; byte-identical to the Pilot-01 `render_prompt` output).
- **P1** — P0 + the evidence-grounding rules block (`P1_rules.txt`), inserted before `# Task`.
- **P2** — P1 + the evidence-citations block (`P2_citations.txt`) + the response-schema
  patch that adds `evidence_refs` (`P2_schema_patch.json`).

**These deltas do not change in v0.2.** The one permitted change to the *shared base
template* is an **answer-neutral** clarification of id-space semantics (§6), applied
**identically to all three conditions**. That is a fix to an under-specified task, not a
tuning of the grounding intervention — see §6 for why it is answer-neutral and for the
fallback if we choose to keep the base byte-identical instead. Every rendered v0.2 prompt
is persisted and hashed, exactly as in Exp 03.

**No-tuning discipline.** All scenario authoring, reference generation, and validity checks
use only the deterministic reference solver and baselines — **never the evaluation model's
outputs**. The evaluation model is run **once per condition** after the matrix is frozen and
validated offline. The P1/P2 wording was fixed in Exp 03 against a single development record
(SRC-104); every v0.2 scenario is unseen by that wording.

---

## 1. Unit of analysis: scenario vs. record vs. task

The POC put all 23 records in one shared pipeline and treated each `(record, level)` pair as
a task. v0.2 makes the **independent scenario** the unit of analysis, because the research
question is about generalization across *cases*, and because the three observability variants
of one probe record are **statistically correlated** (same record, same hidden history, nested
evidence) and must not be counted as three independent examples.

Definitions:

- **Scenario** — a **self-contained mini-pipeline**: its own small set of source records, its
  own final dataset, its own artifacts, authored to isolate **one** target phenomenon around
  **one probe record**. Scenarios are mutually independent (no shared final entities, no shared
  name-collision pool) so per-scenario results are not cross-contaminated. Each scenario is its
  own `Scenario` object fed to the existing `simulate(scenario)` (the simulator already accepts
  an injected scenario) and `build_bundle(sim, level)`.
- **Probe record** — the single `source_id` each scenario asks the model to investigate.
- **Observability variant** — the probe evaluated at a level (`full` / `partial` / `minimal`).
  A scenario declares only the levels that are meaningful for its transition (§7).
- **Condition** — P0 / P1 / P2 (frozen).
- **Task** — one `(scenario, level, condition)` cell, sampled `k` times.

**Independence rule for statistics:** aggregate primary generalization metrics at the
**scenario** level (macro-average across scenarios, or cluster-robust / mixed-effects with the
scenario as the cluster). Per-task tables are reported too, but the headline numbers cluster by
scenario so that a 3-level probe cannot contribute three "independent" wins or losses.

---

## 2. Evidence rules (authoring contract)

These are the rules the deterministic solver already enforces; v0.2 authors every scenario to
satisfy them so the hand-authored expected label always equals `solve(bundle, probe)` (checked
as a gate, §12 step 3). A label is returned **only when positively established** by observable
evidence; otherwise **`UNDETERMINABLE`** (an epistemic statement about evidence, never a hidden
pipeline outcome).

| Label | Positively established by (observable only) | Becomes UNDETERMINABLE when |
|---|---|---|
| `PRESENT_UNDER_OTHER_ID` | (a) a **shared strong id** between the probe and a final row (any level), **or** (b) for a **no-strong-id** record, a `resolution_map` chain probe→canonical→final row on a canonical with **no observable conflict** | the strong id isn't shared and the mapping is gone (only ambiguous names remain) |
| `INGESTION_LOSS` | `ingestion_manifest` **COMPLETE for the probe's batch** and probe absent from it | manifest is `PARTIAL`/`MISSING`, or absence is outside a guaranteed-complete batch |
| `EXTRACTION_LOSS` | probe ingested + `extraction_log` **COMPLETE for `extraction`** + probe failed/empty/absent there | the extraction log is gone |
| `FILTERED_OUT` | probe→canonical (resolution present) + `filter_log` **COMPLETE for `filter`** + that canonical `kept=false` | the filter log is gone (entity merely absent from final) |
| `WRONG_MERGE` | probe carries a strong id, is an observable member of a canonical, an **observable sibling member contradicts it in the same namespace** (rediscovered from members' strong ids, *not* a trusted flag), and the probe's strong id is **absent** from that canonical's final row (probe was absorbed) | the merge log is gone **and** the probe's resolution row is dropped, so the contradiction is no longer observable |

Two invariants the authored evidence must preserve (already tested by `validation.py`,
generalized to N scenarios in §12):

1. **Determinability is monotone.** Removing evidence can turn a determinable answer into
   `UNDETERMINABLE`, never the reverse across `full → partial → minimal`.
2. **No new contradictory positive.** Removing evidence never introduces a *new*
   positively-established label that contradicts a looser level's answer.

**`merge_target_id` observability rule (unchanged).** For `WRONG_MERGE`, `merge_target_id` is
required **only when observable** (the absorbing canonical's final row exists and is
identifiable); otherwise it must be **null**, and the evaluator does not penalize a null. A
target asserted without supporting evidence is scored as a guess, not an answer.

---

## 3. Scenario matrix (15 scenarios)

Each scenario is authored around one probe record. `identifier ids` below use fresh, v0.2-only
namespaces/names (no reuse of SRC-1xx / ENT-5xx / T0x from the POC). Columns: the phenomenon;
the probe's source type; the **reference (evidence-supported) status by level**; and the
**hidden truth** (never in the prompt). "—" means the level is not evaluated for that scenario.

Legend for statuses: `PRES` = `PRESENT_UNDER_OTHER_ID`, `ING` = `INGESTION_LOSS`,
`EXT` = `EXTRACTION_LOSS`, `FILT` = `FILTERED_OUT`, `WM` = `WRONG_MERGE`,
`UND` = `UNDETERMINABLE`.

### Group A — Positive controls (evidence sufficient; the model *should* commit)

| # | Scenario | Probe type | full | partial | minimal | Hidden truth |
|---|---|---|---|---|---|---|
| **S01** | PRESENT via shared **registry** strong id | registry | PRES | PRES | PRES | probe is genuinely present under that final entity |
| **S02** | PRESENT via shared **duns** strong id | directory | PRES | PRES | PRES | genuinely present (directory + registry correctly deduped) |
| **S14** | **Determinable-at-every-level control** — probe present via strong id while *all lineage artifacts are absent at minimal* | registry | PRES | PRES | PRES | present; catches a "minimal ⇒ abstain" shortcut — reduced observability does **not** reduce determinability here |

### Group B — Evidence-transition cases (same record, different defensible answer by level)

| # | Scenario | Probe type | full | partial | minimal | Hidden truth |
|---|---|---|---|---|---|---|
| **S03** | PRESENT via **resolution map only** (news, no strong id) | news | PRES | PRES | **UND** | present under a final entity; at minimal the only identity link (the map) is gone |
| **S04** | **INGESTION_LOSS** | registry | ING | ING | **UND** | never ingested; at minimal the manifest is downgraded to PARTIAL so absence proves nothing |
| **S05** | **EXTRACTION_LOSS** | news | EXT | EXT | **UND** | ingested, extraction failed; extraction log is COMPLETE at full **and** partial, gone at minimal → crosses at partial→minimal |
| **S06** | **FILTERED_OUT** (resolution link survives at partial) | registry | FILT | FILT | **UND** | resolved then dropped; filter log + resolution survive at partial → crosses at partial→minimal |
| **S07** | **WRONG_MERGE**, target **observable** | registry | WM (target set) | **UND** | **UND** | distinct entity absorbed; provable only at full (merge log + conflict); probe's resolution row dropped at partial → crosses at full→partial |
| **S15** | **FILTERED_OUT**, resolution link **dropped at partial** (full-only) | registry | FILT | **UND** | **UND** | same fate as S06 but the surviving lineage link is removed at partial → crosses at full→partial (a full-only shape, contrast with S06) |

> **Correction vs. the first draft (from building against the real observability model):** the
> observability layer keeps the **extraction log and filter log COMPLETE at partial** (only the
> merge-decision log and selected resolution rows drop at partial). So the *only* way to get a
> **full-only** (FULL≠PARTIAL) transition is to remove a lineage link that lives in the merge log
> or a dropped resolution row. S07 (merge) and S15 (filter with a dropped resolution row) are
> therefore the full-only shapes; S03/S04/S05/S06 all cross at **partial→minimal**. S10 and S12
> use **directory records without a DUNS** (no strong id) rather than registry records, because a
> registry probe whose strong id appears in `final_dataset` would be determinable at every level
> (that is S14) and could not be a minimal-abstention probe.

### Group C — Merge / identifier-granularity stress

| # | Scenario | Probe type | full | partial | minimal | Hidden truth |
|---|---|---|---|---|---|---|
| **S08** | **WRONG_MERGE**, target **NOT observable** (absorbing canonical has no final row / no identifiable final id) | registry | WM (target **null**) | — | — | absorbed; the merge is provable but the target id is not, so `merge_target_id` must be null |
| **S13** | **WRONG_MERGE** where lineage exposes the **canonical id** (`C##`) but the correct `merge_target_id` is the **public final id** (`ENT-###`) | registry | WM (target = **final** id) | — | — | directly tests the canonical-vs-final id-granularity issue flagged in Exp 03 |

### Group D — Calibration probes (reference = UNDETERMINABLE; the core generalization test)

These are where a name-matching / over-confident model fails and where grounding (P1/P2) should
help **on unseen records**. All are authored so `name_similarity` (a lineage-free baseline)
would fire a positive, but the evidence does **not** license one.

| # | Scenario | Probe type | Level(s) evaluated | Reference | Hidden truth | The trap |
|---|---|---|---|---|---|---|
| **S09** | **False name match, true entity ABSENT** | news | minimal | **UND** | probe's true entity is **absent** from final; a similarly-named distractor is present | a positive claim is **factually wrong**, not merely unsupported |
| **S10** | **False name match toward a near-duplicate** | directory, no DUNS (no strong id) | minimal | **UND** | probe truly resolved to entity **X** ("…Services"); a name-**identical** look-alike **Y** is a different company | committing to Y is wrong; committing to X is unsupported at minimal |
| **S11** | **Controlled counterfactual A/B** — observationally identical at minimal, only hidden truth differs | news | minimal (one observable condition, two hidden framings) | **UND** (both) | **A:** probe truly is the named entity (present). **B:** probe's true entity is distinct and absent. | the airtight evidence-sensitivity probe (Exp-02 design) on a **new** record |
| **S12** | **Ambiguous multi-match** — two plausible final entities, neither with a lineage/strong-id link | directory, no DUNS (no strong id) | minimal | **UND** | probe resolved to one of them; the other is a decoy | evidence is consistent with ≥2 outcomes → must abstain, not pick one |

**Coverage check.** Labels: PRESENT (S01, S02, S03, S14), INGESTION_LOSS (S04),
EXTRACTION_LOSS (S05), FILTERED_OUT (S06, S15), WRONG_MERGE (S07, S08, S13),
UNDETERMINABLE-by-design (S03/S04/S05/S06/S07/S15 at their lower levels, plus S09–S12).
Requirements coverage: controlled counterfactuals (S09, S11); misleading name matches (S09,
S10, S12); missing/partial lineage (S03–S07, S15); wrong merges (S07, S08, S13);
ingestion/extraction losses (S04, S05); positive controls with sufficient evidence (S01, S02,
S14, plus the FULL level of every transition case).

**Counterfactual construction (S09, S11).** Build the two hidden-truth variants so their
**observable projection at the tested level is byte-identical** (assert by hash), while only the
hidden `true_entity_id` / presence differs. Because the observable evidence is identical, the
reference is identical (`UND`) for both; the hidden truth differs so a positive claim is
"accidentally right" in one framing and "wrong" in the other. This reuses the Exp-02 mechanism
(deep-copy the bundle; alter only hidden truth) generalized to fresh records.

---

## 4. Expected labels & fields (authoring targets)

For each scenario the authored expected answer is the full `ReferenceAnswer`, not just the
status. The generation gate (§12 step 3) asserts `solve(bundle, probe)` equals this table cell
for cell — any mismatch is an **authoring bug**, caught offline before any API spend.

Field expectations by status (unchanged from the evaluator contract):

- `PRES` → `final_id` = the **public `ENT-###`** of the probe's final entity; `merge_target_id` null.
- `WM` → `final_id` null; `merge_target_id` = the absorbing entity's **public final id** when
  observable (S07, S13), else **null** (S08).
- `ING` / `EXT` / `FILT` / `UND` → both id fields null.

Per-scenario the spec will also record: the probe's strong id (if any), the distractor final
entity/entities and their name-similarity to the probe (to document the trap strength), the
`partial`-level redaction policy (which resolution rows / logs are dropped, §11 step 2), and,
for calibration probes, the exact hidden-truth twin.

---

## 5. Extended evidence-chain validation (Requirement 5)

Exp 03's `chain_validity` returned a single boolean (grounded ∧ status-sufficient). v0.2 splits
it into three deterministic validities, computed only for **positive** P2 answers (abstentions
have empty `evidence_refs` and are scored on status alone):

1. **`status_evidence_validity`** — the cited artifacts (a) exist and are **non-MISSING**, (b)
   sit in a **guaranteed-complete scope** where the rule requires one, (c) contain **no
   name-similarity citation**, and (d) are **sufficient**: they instantiate the solver's rule
   for the claimed status (e.g. a shared strong id or a valid `resolution_map` chain for `PRES`;
   a same-namespace member contradiction + absorbed-identity for `WM`). Does the chain establish
   the **status**?
2. **`identifier_evidence_validity`** — the cited artifacts establish the claimed **identifier**
   at the **correct id-granularity**: the reported `final_id` / `merge_target_id` is a **public
   `ENT-###`** present in `final_dataset` (not an internal `C##`), and the citation actually
   resolves to that id (strong-id row, or `resolution_map` canonical → `final_dataset.canonical_id`
   → `final_id`). This is the metric that would have caught the Exp-03 `C11`-vs-`ENT-502` slip.
3. **`full_evidence_validity`** = `status_evidence_validity` ∧ `identifier_evidence_validity`.

**Robustness change (recommended, answer-neutral).** Exp-03 validity parsed free-text refs by
substring. v0.2 should adopt a light **structured** `evidence_refs` schema so validation is
deterministic rather than string-sniffing — e.g. each ref is
`{"artifact": "<name>", "row_key": "<source_id|canonical_id|final_id>", "field": "<optional>"}`.
This is a schema change to the P2 **response format only**; it does not add answer hints and is
applied uniformly. (If we prefer zero change to the frozen P2 delta, keep free-text refs and
validate with the existing substring approach plus an id-granularity check — noted as the
fallback in §6/§13.)

---

## 6. Canonical-id vs final-id semantics (Requirement 6)

**Problem.** Lineage artifacts key on the internal `canonical_id` (`C##`); the public identity
is `final_id` (`ENT-###`) in `final_dataset`. In Exp 03 the model sometimes reported the
canonical id as `merge_target_id`. This is an **under-specification of the task**, and it
confounds the identifier metric.

**Resolution (answer-neutral clause added to the shared base template, all conditions):**

> *The pipeline uses two id spaces. `canonical_id` (e.g. `C10`) is an **internal** id assigned
> at resolution and appears in the intermediate artifacts. `final_id` (e.g. `ENT-501`) is the
> **public** id in `final_dataset`. Whenever you report `final_id` or `merge_target_id`, report
> the **public `final_id`** from `final_dataset`, never the internal `canonical_id`. To convert,
> match the artifact's `canonical_id` to `final_dataset.canonical_id` and read its `final_id`.*

**Why this is answer-neutral (not tuning):** it is applied **identically** to P0, P1, and P2;
it names no scenario, label, entity, or correct answer; it only defines the output vocabulary.
It changes the shared **base**, not the frozen P1/P2 **deltas**, so "P0/P1/P2 frozen" is honored
at the level of the intervention that the experiment is about. Every rendered v0.2 prompt is
hashed under a new base version tag (`base_v2`) so the change is auditable.

**Fallback (if we prefer the base byte-identical to Exp 03):** keep the template unchanged, do
**not** add the clause, and instead score the canonical-vs-final slip purely through
`identifier_evidence_validity` and `full_correct`, documenting the id ambiguity as a known
task-format limitation rather than fixing it. This maximally preserves "frozen" but leaves the
confound in the identifier metrics. **Recommendation: adopt the clause** (Requirement 6 asks us
to resolve the semantics *in the task specification*), and report identifier metrics with a note
that the clause is a task-spec fix, not a grounding change. This choice is flagged for your
ratification.

---

## 7. Which levels each scenario runs

Running every scenario at all three levels wastes budget on cells with no evidential meaning.
Each scenario declares the levels that bracket its phenomenon:

- **Positive controls (S01, S02, S14):** all three levels (they must stay `PRES` throughout;
  S14 specifically checks that minimal ≠ abstain).
- **Transitions (S03, S04, S05, S06):** all three levels; they cross determinable→UND at
  **partial→minimal**.
- **S07 (WRONG_MERGE observable) and S15 (FILTERED_OUT, resolution dropped at partial):** all
  three; they cross at **full→partial** (the full-only shapes).
- **Merge/id stress (S08, S13):** **full only** (the phenomenon is a full-level positive; lower
  levels would just be `UND` and are covered by S07).
- **Calibration probes (S09, S10, S12):** **minimal only** (the trap is an
  insufficient-evidence abstention). **S11:** one observable minimal condition, two hidden
  framings.

Level count: 3×(S01,S02,S03,S04,S05,S06,S07,S14,S15) + 1×(S08,S13,S09,S10,S12) + 1×(S11 obs
cond) = **27 + 6 = 33 observable task-conditions per prompt condition**. See §10 for sampling
and cost.

---

## 8. Baselines & baseline-unsolvability (Requirement 8)

Reuse the existing lineage-free baselines unchanged: `name_similarity`, `strong_id`,
`source_final_only`. Because they never read intermediate artifacts, their answer is identical
at every level — so they **cannot** reproduce level-dependent references, by construction.

v0.2 authors the calibration probes so that the baselines' failure is **explicit and
demonstrative**:

- On **S09, S10, S12** (reference `UND` at minimal), `name_similarity` fires a **positive** →
  a documented baseline error exactly where the reference says abstain. This is the evidence
  that these tasks require calibration, not name matching.
- On **S01, S02, S14**, `strong_id` succeeds → confirms these are genuine positive controls.
- The **unsolvable-by-lineage-free-baseline** set is reported (as today, with the same caveat
  that it reflects the *implemented* baselines, not a proof that no lineage-free strategy could
  solve them): expected to include the FULL/PARTIAL determinable levels of S03–S07/S15 and the
  full-only merges S08/S13.

The generalization claim is only interesting **above** this baseline floor: we report the frozen
model+grounding accuracy on the calibration probes against the baseline's (wrong) positives.

---

## 9. Metrics (Requirement 7 & 8)

Reported **per task** and **per scenario** (clustered). Primary generalization headlines are
**macro-averaged across scenarios**.

Status/answer:
- **Evidence-supported status accuracy** (vs. reference).
- **Full-answer accuracy** (status + id fields).

Calibration (on reference-`UND` tasks):
- **Unsupported-positive rate** — fraction emitting any positive status. *Primary generalization
  metric* (does frozen P1/P2 keep this ≈0 on unseen records?).
- **Correct-abstention rate.**

Commitment (on determinable tasks):
- **Correct-positive rate** (status and full). *Guards against over-abstention* — must not fall
  vs. P0.

Transition (per scenario, clustered — the benchmark's raison d'être):
- **Paired evidence-transition accuracy** — for a probe with a determinability transition, a
  sample is transition-correct iff it is correct at **both** bracketing levels (commits when the
  evidence is present **and** abstains when it is removed). Reported per scenario and macro-averaged.

Evidence chain (P2 positives only), three-way per §5:
- **`status_evidence_validity`**, **`identifier_evidence_validity`**, **`full_evidence_validity`** rates.

Baselines:
- Per-baseline accuracy; unsolvable-by-baseline set; model-minus-baseline on calibration probes.

Cost/usage: input/output tokens and USD per condition and total.

**Generalization verdict rule (stated in advance).** The Exp-03 effect *generalizes* iff, on the
unseen v0.2 scenarios, moving P0→P1 (and P0→P2): (i) **reduces** macro unsupported-positive rate,
(ii) does **not reduce** macro correct-positive rate (no over-abstention), and (iii) does not
reduce macro status accuracy. P2 additionally should show high `full_evidence_validity`. We fix
this rule now so the analysis is not chosen after seeing results.

---

## 10. Sampling, determinism, and cost

- **Samples per cell `k`.** Exp 03 used `k=1`; §5/§9 need stable rates, and the calibration
  probes are the whole point. Recommend **`k=3`** for all cells, bumped to **`k=5`** for the
  four calibration probes (S09–S12). Model `claude-sonnet-5`, `max_tokens=8192`,
  `temperature=0.0`, unchanged. (temperature 0 is not fully deterministic on the API, which is
  exactly why `k>1` matters.)
- **Call budget.** 33 task-conditions × 3 prompt conditions = 99 cells. At `k=3` that's ~297
  calls; the calibration probes at `k=5` add ~4 probes × 3 conditions × 2 extra samples ≈ 24 →
  **~320 calls**. Exp 03 cost ≈ $0.021/call ⇒ **≈ $7** primary run. `k=5` everywhere would be
  ~$11–14. Counterfactual twins (S09, S11) add only *interpretation*, not extra observable
  conditions, so no extra calls beyond their minimal cells.
- **Resumability & preservation.** Reuse the Exp-03 harness pattern: fingerprint =
  (model, provider, max_tokens, temperature, prompt_sha256); skip cells with a saved response;
  persist every request param, raw response, parsed prediction, tokens, and the three validity
  flags. Replay re-scores with zero API calls.

---

## 11. Reused vs. new components

**Reused unchanged:** `models.py` (Scenario/ScenarioRecord/FinalEntity, ObservableBundle,
ReferenceAnswer, the six labels, three-valued ArtifactState, StrongId), `simulator.simulate`
(already accepts an injected `scenario`), `observability.build_bundle`, `solver.solve`,
`evaluator` (parse/evaluate/summarize), `baselines`.

**New / extended (minimal):**
1. **`scenarios_v2/`** — 15 hand-authored `Scenario` objects + a `ScenarioSpec` wrapper carrying
   `scenario_id`, `phenomenon`, `probe_source_id`, evaluated `levels`, the per-level partial-drop
   policy, the counterfactual twin (for S09/S11), the authored expected `ReferenceAnswer` per
   level, and documented distractor/name-similarity metadata.
2. **Per-scenario observability policy.** `observability.PARTIAL_RESOLUTION_DROP` is currently a
   module-global `{"SRC-104","SRC-106"}`. Generalize it to a policy carried on the scenario/spec
   (which resolution rows and which logs to drop at `partial`), defaulting to today's behavior for
   the existing POC scenario so nothing breaks.
3. **Three-way evidence-chain validators** (§5) + (recommended) structured `evidence_refs` schema.
4. **v0.2 prompt builder** — shared `base_v2` template (frozen P0 text + the answer-neutral
   id-space clause, §6) with the frozen P1/P2 deltas loaded from `prompts/frozen_v1/`; renders and
   hashes every prompt.
5. **v0.2 runner + reporter** — matrix over scenarios × levels × conditions; per-task and
   per-scenario (clustered) metrics of §9; offline dry-run first.

---

## 12. Implementation sequence (execute in order; no API calls until step 9)

1. **Author scenarios.** Write the 15 `Scenario` objects + `ScenarioSpec`s (§3, §4) with fresh
   ids/names. Encode each hidden-truth twin for S09/S11.
2. **Per-scenario observability policy.** Refactor `PARTIAL_RESOLUTION_DROP` into a per-scenario
   drop policy; keep the POC default. Add unit tests that the POC scenario's bundles are byte-identical
   to before (regression guard).
3. **Reference-generation gate (offline).** For every scenario × evaluated level, assert
   `solve(bundle, probe)` equals the authored expected `ReferenceAnswer`. Any mismatch is an
   authoring bug — fix the scenario, never the solver. This is the primary correctness gate.
4. **Counterfactual hash gate (offline).** For S09/S11, assert the two hidden-truth variants have
   **byte-identical** observable projections at the tested level (hash), and identical references.
5. **Generalized validation checks (offline).** Extend `validation.py` to run across all scenarios:
   monotonicity, no-new-contradictory-positive, no ground-truth leakage, redaction-only-removes,
   distractors present, and the headline "same record → different defensible answer across levels"
   for every transition scenario.
6. **Baselines (offline).** Run the lineage-free baselines across the matrix; produce the
   unsolvable-by-baseline set and assert the calibration-probe baseline errors (§8).
7. **Evidence-chain validators (offline).** Implement the three validities (§5) + structured
   `evidence_refs` (or the fallback). Unit-test them against solver-derived **positive** fixtures
   (valid chains) and **adversarial** fixtures (name-similarity-only refs, MISSING-artifact refs,
   canonical-id-instead-of-final-id) — no LLM involved.
8. **Prompt build + freeze check (offline).** Render all prompts from `base_v2` + frozen deltas;
   assert the P1/P2 deltas match `prompts/frozen_v1/manifest.json` hashes; persist and hash every
   rendered prompt.
9. **Opt-in pilot (API).** Only now, with a cost estimate and `k` decided, run the resumable pilot
   (§10), preserving every raw response. Replay-scorable.
10. **Analyze & report.** Produce per-task and per-scenario (clustered) metrics (§9), apply the
    pre-registered generalization verdict rule, and write `experiments/` (or `analysis/`) report.
    **Do not modify any prompt after seeing evaluation outputs.**

---

## 13. Open decisions for your ratification

1. **Id-space clause (§6):** adopt the answer-neutral base-template clause (recommended, satisfies
   Requirement 6) vs. keep the base byte-identical and score the slip only via validity (fallback).
2. **Structured `evidence_refs` (§5):** adopt the light structured schema for robust deterministic
   validation (recommended) vs. keep Exp-03 free-text refs + substring validation.
3. **Sample size (§10):** `k=3` (+`k=5` on calibration probes) ≈ $7 (recommended) vs. `k=5`
   throughout ≈ $11–14.
4. **Scenario count:** 15 as specified vs. trim to 12 (drop S15 and one of the near-duplicate
   calibration probes S10/S12) for a leaner first pass.
5. **Location of the v0.2 report:** `experiments/exp04-v0.2-generalization/` (consistent with the
   experiment log) vs. a top-level `benchmark/` once it graduates from "experiment" to "benchmark."

No code will be written until these are settled.
