# Pilot 01 — Analysis

- **Model:** `claude-sonnet-5`
- **Run:** `20260925T162833Z-seed20260925-a4b362` (raw responses preserved under
  [runs/sample/pilot-01/](../runs/sample/pilot-01/))
- **Tasks:** 18 (6 unique source records × Full/Partial/Minimal), paired design
- **Two attempts:**
  - *Attempt 1 (original):* `max_tokens=2048`. Two Partial tasks truncated (see Failure
    Mode 1). Responses under `responses/`.
  - *Attempt 2 (retry):* the **two truncated tasks only** re-run at `max_tokens=8192`, all
    other request parameters (model, prompt, artifacts, temperature) unchanged. Responses
    under `retry_maxtok8192/`. The **completed run** = attempt-1's 16 produced answers +
    attempt-2's 2 answers.
- **Config:** temperature not sent (Sonnet 5 rejects it), adaptive thinking on by default.

---

## Headline — completed run (attempt 1 + retry)

| Metric | All-task (18) | Valid-response-only |
|---|---|---|
| Status accuracy | **94.4%** (17/18) | 94.4% (17/18) |
| Full-answer accuracy | **88.9%** (16/18) | 88.9% (16/18) |
| Malformed | **0** | — |

After the retry every task has a valid response, so all-task and valid-only coincide. Only
two genuine errors remain: `SRC-106:full` (id-granularity) and `SRC-104:minimal` (name
trap).

### By observability level (completed run)

| Level | Status acc. | Full acc. | Malformed | Only miss |
|---|---|---|---|---|
| Full    | **100%** (6/6) | 83% (5/6) | 0 | canonical-vs-final id (SRC-106:full) |
| Partial | **100%** (6/6) | **100%** (6/6) | 0 | — (both retried tasks correct) |
| Minimal | 83% (5/6) | 83% (5/6) | 0 | name-similarity false positive (SRC-104:minimal) |

**The earlier "Partial is worst" dip was entirely the truncation artifact.** With adequate
output budget, Partial is perfect: the model correctly abstains (`UNDETERMINABLE`) on both
hard Partial tasks. The only substantive weakness is at Minimal.

### Attempt 1 (original) headline, for the record

| Metric | Value |
|---|---|
| Status accuracy | 83.3% (15/18) all-task · 93.8% (15/16) valid-only |
| Full-answer accuracy | 77.8% (14/18) all-task · 87.5% (14/16) valid-only |
| Malformed | 2/18 (`SRC-106:partial`, `SRC-104:partial` — truncation) |

---

## Per-record predictions across levels

`✓` full-correct · `~` status-correct only · `✗` wrong status · `MAL` malformed

Predictions below are the **completed run** (retried cells marked †). Reference answer in
parentheses where it differs from the model.

| record | actual | Full | Partial | Minimal |
|---|---|---|---|---|
| SRC-106 (wrong merge) | WRONG_MERGE | `WRONG_MERGE` ~ (gave `C11` not `ENT-502`) | `UNDETERMINABLE` ✓ † | `UNDETERMINABLE` ✓ |
| SRC-104 (present via map) | PRESENT | `PRESENT ENT-501` ✓ | `UNDETERMINABLE` ✓ † | `PRESENT ENT-501` ✗ (ref = UNDETERMINABLE) |
| SRC-101 (ingestion loss) | INGESTION_LOSS | `INGESTION_LOSS` ✓ | `INGESTION_LOSS` ✓ | `UNDETERMINABLE` ✓ |
| SRC-102 (extraction loss) | EXTRACTION_LOSS | `EXTRACTION_LOSS` ✓ | `EXTRACTION_LOSS` ✓ | `UNDETERMINABLE` ✓ |
| SRC-107 (filtered) | FILTERED_OUT | `FILTERED_OUT` ✓ | `FILTERED_OUT` ✓ | `UNDETERMINABLE` ✓ |
| SRC-109 (present via DUNS) | PRESENT | `PRESENT ENT-503` ✓ | `PRESENT ENT-503` ✓ | `PRESENT ENT-503` ✓ |

† Retried at `max_tokens=8192`. Original attempt-1 outputs for these two cells were empty
(truncated). **Retried predictions:**

| task | attempt-1 | retry (`max_tokens=8192`) | reference |
|---|---|---|---|
| `SRC-106:partial` | empty (truncated, 2048 out) | `UNDETERMINABLE` ✓ (937 out tok) | UNDETERMINABLE |
| `SRC-104:partial` | empty (truncated, 2048 out) | `UNDETERMINABLE` ✓ (3392 out tok) | UNDETERMINABLE |

Both retries are **correct abstentions**. The control (SRC-109, strong id shared with
final) is correct at every level. Every Partial answer is now correct; the only Minimal
miss is SRC-104.

---

## Failure modes

### 1. Thinking-token truncation (2 tasks) — config artifact, RESOLVED by the retry
In attempt 1, `SRC-106:partial` and `SRC-104:partial` returned **empty text** with
`output_tokens = 2048` (the cap). Sonnet 5 runs adaptive thinking with `display: omitted`,
so the entire output budget was consumed by (hidden) reasoning and the JSON was never
emitted. Both are the Partial cases whose correct answer is `UNDETERMINABLE`.
**Re-running just these two at `max_tokens=8192` (all else unchanged) resolved it: both now
return the correct `UNDETERMINABLE`** (937 and 3392 output tokens respectively — the second
would still have truncated at 2048). This was purely an output-budget issue, not a
reasoning failure. **Takeaway for all future runs: set `max_tokens ≥ 4096` because adaptive
thinking shares the output budget.**

### 2. Name-similarity false positive (1 task) — the target failure mode
`SRC-104:minimal`: reference is `UNDETERMINABLE` (the resolution mapping is gone, the
record is a news mention with no strong id, and the name is ambiguous between `ENT-501`
"Vertex Materials Inc" and the distractor `ENT-509` "Vertex Media Group"). The model
answered `PRESENT_UNDER_OTHER_ID → ENT-501`. Notably, that guess **matches the hidden
truth** (SRC-104 really is ENT-501) — but it is **not supported by the available
evidence**. This is exactly the "plausible guess vs. evidence-supported conclusion"
distinction the benchmark is built to test: the model resolved a name it should have
flagged as undeterminable, and ignored the available distractor.

### 3. Identifier-granularity error (1 task)
`SRC-106:full`: the model correctly identified `WRONG_MERGE` (status correct) and even
named the right cluster, but returned `merge_target_id = "C11"` (the internal **canonical**
id) instead of `"ENT-502"` (the **final-dataset** id required). "Right cluster, wrong
id-space." Status-correct but not full-correct.

---

## Incorrect positives vs. incorrect UNDETERMINABLE

Completed run (all 18 valid, 0 malformed):

| Error type | Count | Which |
|---|---|---|
| Incorrect **positive** (claimed a determinate answer when ref = UNDETERMINABLE) | **1** | SRC-104:minimal |
| Incorrect **UNDETERMINABLE** (abstained when a determinate answer was supported) | **0** | — |
| Id-granularity (right status, wrong id) | 1 | SRC-106:full |

**The asymmetry is the key signal:** Sonnet 5's only status error is *over-claiming* (the
name trap), never *over-abstaining*. Across all 18 tasks it never abstained on a
determinable task.

## Correct abstentions after evidence removal

The model correctly collapsed to `UNDETERMINABLE` in **6 of 6** abstention cases: at Minimal
for SRC-101, SRC-102, SRC-107, SRC-106, **and** at Partial for SRC-106 and SRC-104 (the two
retried tasks). It reasons about scoped completeness / missing lineage reliably. In
particular it did **not** fall for the strongest name trap: SRC-106 ("Blue Harbour Capital
Partners" vs. the final "Blue Harbor Capital") correctly abstained at both Partial and
Minimal rather than claiming PRESENT.

## Name-similarity reliance despite insufficient evidence

Confirmed exactly once — **SRC-104:minimal**. Crucially, the retry shows SRC-104 at
**Partial** correctly abstains (`UNDETERMINABLE`), so the model only slips into the name
match at the *lowest* evidence level, where the resolution map, extraction log, and
normalized records are all gone and only the ambiguous source name + final list remain. The
model resisted the harder trap (SRC-106) at every level but fell for the softer Vertex trap
at Minimal only. This single Minimal-level over-claim is the most benchmark-relevant finding.

---

## Comparison against the deterministic baselines

The three lineage-free baselines each solve only 3–4 of the 11 determinable tasks and solve
**none** of the 7 tasks that the baselines cannot reach. Verified against the actual task
ids, that set of 7 is exactly:

> `SRC-106:full`, `SRC-101:full`, `SRC-102:full`, `SRC-107:full`,
> `SRC-101:partial`, `SRC-102:partial`, `SRC-107:partial`

**Correction to a claim in the first draft:** these 7 are *not* the truncated tasks. The
two truncated tasks were `SRC-106:partial` and `SRC-104:partial`, both of which have
**UNDETERMINABLE** references and are therefore not in the lineage-required set at all. The
completed run has **no truncated lineage-required task**.

On those 7 lineage-required tasks the LLM is **full-correct on 6** and status-correct on the
7th (`SRC-106:full`, the id-granularity slip). So the model beats every lineage-free
baseline precisely on the tasks that require lineage — clear evidence it is using lineage
evidence, not names.

| | determinable solved (of 11) | lineage-required solved (of 7) |
|---|---|---|
| name_similarity | 4 | 0 |
| strong_id | 3 | 0 |
| source_final_only | 4 | 0 |
| **claude-sonnet-5** (completed) | **10 full / 11 status** | **6 full + 1 status** |

---

## Token usage & cost

Sonnet 5 @ $2/1M input, $10/1M output.

| Attempt | Input tok | Output tok | Cost |
|---|---|---|---|
| Attempt 1 — original 18 calls (incl. the 2 truncated) | 142,800 | 11,779 | $0.4034 |
| Attempt 2 — retry, 2 calls @ 8192 | 17,686 | 4,329 | $0.0787 |
| **Total (original + retries)** | **160,486** | **16,108** | **≈ $0.48** |

Input dominates and is driven by the Full prompts (all six artifacts inline; ~9.4k tokens
each). The two truncated attempt-1 calls still cost their full 2,048 output tokens each.

---

## Recommendations for the next iteration (no dataset expansion yet)

1. **Default `max_tokens ≥ 4096`** in the config (adaptive thinking shares the output
   budget). Confirmed by the retry — this alone removed the only malformed responses.
2. **Clarify the id-space** in the prompt (answers must be final `ENT-` ids, never internal
   `C` canonical ids), or score "right cluster, wrong id" as its own category. `SRC-106:full`
   shows the model reasons correctly but reports the wrong id granularity. *(The user has
   flagged this as a separate experiment — do not change the identifier instructions yet.)*
3. **The name trap is the signal.** `SRC-104:minimal` is a clean instance of
   evidence-insufficient over-claiming, and it appears **only at Minimal** (SRC-104:partial
   correctly abstains). When we expand, add more Minimal-level ambiguous cases and make the
   Minimal over-claiming rate a headline metric — it is the behavior the benchmark most
   uniquely exposes.
4. Consider multi-sample (self-consistency) on the trap cases to check whether the
   name-similarity slip is stable or stochastic.

**Bottom line (completed run):** Sonnet 5 scores **94.4% status / 88.9% full-answer** with
zero malformed. It clearly uses lineage over names (beats every lineage-free baseline on all
7 lineage-required tasks) and abstains correctly whenever evidence is removed (6/6). Only
two errors remain: one id-granularity slip (`SRC-106:full`, status still correct) and one
genuine evidence-vs-guess failure — the `SRC-104:minimal` name trap, which is exactly the
failure mode the benchmark is designed to catch.
