# Frozen prompt conditions — v1

P0 / P1 / P2 exactly as evaluated in **Experiment 03**. This directory is an **immutable, hash-verified freeze**.

- `P1_rules.txt` — the evidence-grounding rules block (P1 delta over P0).
- `P2_citations.txt` — the mandatory-evidence-citations block (P2 adds this on top of P1).
- `P2_schema_patch.json` — the response-schema edit P2 makes (adds `evidence_refs`).
- `manifest.json` — version, per-delta sha256, and the sha256 of every rendered Exp-03 prompt file (`experiments/exp03-prompt-intervention/prompts/{P0,P1,P2}/*.txt`).

**Contract for Benchmark v0.2:** reuse these condition *deltas* unchanged. The v0.2 task template may add answer-neutral scaffolding (e.g. the canonical-vs-final id clause) to the shared base applied identically to all three conditions, but the P1/P2 deltas above must stay byte-identical. Never tune them against the v0.2 evaluation set. If a change is ever required, create `frozen_v2/` — do not edit v1.
