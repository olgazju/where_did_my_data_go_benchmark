# Experiment 04 — evidence-validator audit (offline)

**Scope:** an offline audit of the 12 P2 evidence-chain validation *failures* from the Exp-04 run.
No API calls. The original Exp-04 results are **frozen and unchanged**
([`frozen_original/`](frozen_original/)); corrected metrics are reported **separately** below.
Prompts, scenarios, reference labels, and historical run artifacts were not modified.

## 1–2. The 12 failures, individually classified

All 12 v1 "status-invalid" answers are **`full_correct=True`** — this is a *citation-scoring*
question, not an answer-correctness one. Per-case (see `audit_rescore.py` for the reproducible
grounding of every ref):

| # | Cell | Pred | v1 | Cause | Verdict |
|---|---|---|---|---|---|
| 1 | S01:full#3 | PRESENT | ✗ | real `normalized_records` row cited with `strong_ids` as a **list** — v1 matcher can't match lists | **false negative** |
| 2 | S01:minimal#1 | PRESENT | ✗ | source strong id cited via real field `registration_number`, not synthetic `strong_id` | **false negative** |
| 3 | S01:minimal#2 | PRESENT | ✗ | same (`registration_number`) | **false negative** |
| 4 | **S01:minimal#3** | PRESENT | ✗ | cites final strong id + `ingestion_manifest` "ingested"; **never cites the source-side strong id** | **genuine weak citation** |
| 5 | S02:minimal#1 | PRESENT | ✗ | source strong id cited via real field `duns` | **false negative** |
| 6 | S02:minimal#2 | PRESENT | ✗ | same (`duns`) | **false negative** |
| 7 | S02:minimal#3 | PRESENT | ✗ | same (`duns`) | **false negative** |
| 8 | S04:full#1 | INGESTION_LOSS | ✗ | cites the manifest's **completeness guarantee** for the batch — no *row* exists for an absent record, and v1 had no completeness-citation form | **schema gap** |
| 9 | S13:full#1 | WRONG_MERGE | ✗ | real `normalized_records` rows cited with `strong_ids` as a **list** | **false negative** |
| 10 | S14:minimal#1 | PRESENT | ✗ | `registration_number` field | **false negative** |
| 11 | **S14:minimal#2** | PRESENT | ✗ | final strong id + "ingested"; **no source-side strong-id link** | **genuine weak citation** |
| 12 | S14:minimal#3 | PRESENT | ✗ | `registration_number` field | **false negative** |

**Summary: 10 validator false negatives (9 field/list + 1 absence-schema gap), 2 genuine weak
citations.** The two genuine cases (#4, #11) prove presence from "the final entity has strong id X
and this record was ingested" without ever citing that *the record itself* carries X — the identity
link is not pinned, so they should remain invalid.

## 3. Validator correction (v2) — sufficiency and integrity kept separate

New module [`validators_v2.py`](validators_v2.py) (v1 is preserved unchanged). It splits the metric
into two independent axes, as requested:

- **`citation_integrity`** — every cited ref names a **real observable row** (or a genuine
  completeness guarantee), never a hallucinated or MISSING one.
- **`evidence_sufficiency`** — the **grounded** refs actually establish the claimed status.
- `status_evidence_validity = integrity ∧ sufficiency ∧ status==reference`.

Three corrections, each justified by an audited false negative — **not** relaxations of rigor:

- **(A) Real strong-id field names.** A source strong-id citation may use `registration_number`
  (registry) or `duns` (directory); the share is **re-derived from the actual matched rows**, so it
  cannot be faked by naming a field.
- **(B) List-valued fields** (`strong_ids`, `members`) match by membership *or* whole-list equality.
- **(C) Absence-based citations.** `{"guaranteed_complete_for": "<batch>"}` grounds iff the artifact
  is genuinely COMPLETE for that scope — the only honest way to cite `INGESTION_LOSS` (absence within
  a complete scope), which has no row to point at.

**v2 is not over-lenient (adversarial assertions, all pass):** it still rejects name-only citations,
MISSING-artifact citations, canonical-id-as-final-id, a completeness scope the artifact does not
guarantee, and the two genuine weak citations. Tests: `audit_rescore.py::test_v2_not_overlenient`
and the v1 suite `test_validators.py` (9/9 pass).

## 4–5. Corrected metrics (re-scored offline; originals preserved separately)

Re-scoring the **preserved** 63 positive P2 responses with v2 (no API calls,
[`corrected_evidence_validity.json`](corrected_evidence_validity.json)):

| P2 evidence-chain metric | Original (v1, frozen) | Corrected (v2) |
|---|---|---|
| `status_evidence_validity` | 0.810 (51/63) | **0.968 (61/63)** |
| — `citation_integrity` (new axis) | — | **1.000 (63/63)** |
| — `evidence_sufficiency` (new axis) | — | **0.968 (61/63)** |
| `identifier_evidence_validity` | 1.000 (63/63) | **1.000 (63/63)** |
| `full_evidence_validity` | 0.810 (51/63) | **0.968 (61/63)** |

- **10 false negatives fixed**; the **2 remaining invalids are genuine weak citations**
  (`S01:minimal#3`, `S14:minimal#2`).
- **Citation integrity is 100%** — across all 63 positive P2 answers, every cited row was real and
  observable; **no hallucinated or MISSING-artifact citation anywhere**.
- **Identifier validity remains 100%** — no canonical-vs-final id confusion; the Exp-03 slip did not
  recur.

**These corrections change only the P2 evidence-chain validity metric.** Status/full accuracy,
unsupported-positive rate, correct-abstention/-positive rates, and transition accuracy are
**unchanged**, and the pre-registered generalization verdict (P1 and P2 PASS) **stands**. The
original Exp-04 numbers remain as reported in `frozen_original/`; v2 is proposed for future runs.

## 6. Determinable task-condition count — reconciled with the matrix

`analysis.md` prose said "23 observable determinable task-conditions." The task matrix gives:

- **33** observable task-conditions (scenario × level) total.
- **21 determinable** (reference ≠ UNDETERMINABLE): PRESENT ×11, FILTERED_OUT ×3, WRONG_MERGE ×3,
  INGESTION_LOSS ×2, EXTRACTION_LOSS ×2.
- **12 undeterminable**.
- All determinable cells are k=3 ⇒ **63 determinable samples per condition** (21 × 3), which is
  exactly the number of positive P2 answers scored above.

**Correct count is 21 (not 23).** This is a narrative correction only: every computed metric
(correct-positive rate, etc.) was already denominated on the actual 63 determinable samples, so **no
result value changes**. The "23" figure in the frozen `analysis.md` is superseded by this
reconciliation (the frozen file is left intact for provenance).

## Decision recorded (not yet implemented)

P2 is chosen as the single official benchmark prompt going forward; P0/P1 are retained for historical
reproducibility. **Prompt consolidation is not implemented in this audit** — deferred to benchmark
packaging.

## Stop point

Audit complete. No further steps taken. Artifacts: `validators_v2.py`, `audit_rescore.py`,
`corrected_evidence_validity.json`, and this report; originals under `frozen_original/`.
