"""Benchmark v0.2 prompt conditions.

Shared base template (`base_v2`) = the frozen P0 render + an answer-neutral id-space clause,
applied IDENTICALLY to all three conditions (decision #1). The P1 grounding block is loaded
from `prompts/frozen_v1/` and used BYTE-IDENTICAL (freeze-checked here). P2 uses a NEW,
explicitly-versioned structured `evidence_refs` output contract (decision #2); the original
free-text P2 contract in `frozen_v1/` is preserved untouched and documented separately.

  base_v2 = P0(render) with the id-space clause inserted before '# Task'
  P0_v2   = base_v2
  P1_v2   = base_v2 + frozen P1 grounding block (unchanged) before '# Task'
  P2_v2   = P1_v2 + structured-citations block (v2) before '# Task' + structured schema patch
"""
from __future__ import annotations

import hashlib
from pathlib import Path

from poc.models import ObservableBundle
from poc.prompts import render_prompt

REPO = Path(__file__).resolve().parents[2]
FROZEN = REPO / "prompts" / "frozen_v1"

# Frozen P1 grounding block — loaded from disk, used unchanged (freeze-checked in freeze_check()).
P1_RULES = (FROZEN / "P1_rules.txt").read_text()

# Answer-neutral id-space clause (decision #1). Names no scenario/label/entity/answer.
ID_CLAUSE = """\
# Identifier reporting
The pipeline uses two id spaces. `canonical_id` (e.g. "C10") is an INTERNAL id assigned at
resolution and appears in the intermediate artifacts. `final_id` (e.g. "ENT-501") is the PUBLIC
id in `final_dataset`. Whenever you report `final_id` or `merge_target_id`, report the PUBLIC
`final_id` from `final_dataset`, never the internal `canonical_id`. To convert, match an
artifact's `canonical_id` to `final_dataset.canonical_id` and read its `final_id`.

"""

# Versioned structured-citation block (v0.2 P2 output contract; supersedes the frozen free-text one).
P2_CITATIONS_V2 = """\
# Evidence citations (required, structured)
For any status other than UNDETERMINABLE you MUST populate "evidence_refs" with a JSON array of
citation objects, each of the form {"artifact": "<artifact name>", "match": {"<field>": "<value>"}},
drawn ONLY from the artifacts shown above. Cite the specific rows that establish your conclusion,
e.g. {"artifact": "resolution_map", "match": {"source_id": "SRC-1", "canonical_id": "C10"}} or
{"artifact": "final_dataset", "match": {"final_id": "ENT-501", "strong_id": "duns/11-2200-345"}}.
Do NOT cite name similarity. If you cannot cite establishing artifacts, answer UNDETERMINABLE with
"evidence_refs": [].

"""

# The final schema line in the frozen P0 render (kept identical to frozen_v1's _MERGE_LINE).
_MERGE_LINE = ('  "merge_target_id": "<the id it was wrongly merged into if status is WRONG_MERGE '
               'and that id is observable, else null>"\n}')
# Structured P2 schema patch (v2): evidence_refs is an array of {artifact, match} objects.
_MERGE_LINE_P2_V2 = (
    '  "merge_target_id": "<the id it was wrongly merged into if status is WRONG_MERGE '
    'and that id is observable, else null>",\n'
    '  "evidence_refs": [{"artifact": "<artifact name>", "match": {"<field>": "<value>"}}]'
    '  // use [] for UNDETERMINABLE\n}'
)

CONDITIONS = ("P0", "P1", "P2")


def build_prompts(p0: str) -> dict[str, str]:
    base = p0.replace("# Task", ID_CLAUSE + "# Task", 1)
    p1 = base.replace("# Task", P1_RULES + "# Task", 1)
    p2 = p1.replace("# Task", P2_CITATIONS_V2 + "# Task", 1).replace(_MERGE_LINE, _MERGE_LINE_P2_V2, 1)
    assert "evidence_refs" in p2, "P2 structured schema patch failed"
    assert ID_CLAUSE in base and ID_CLAUSE in p1 and ID_CLAUSE in p2, "id clause missing from a condition"
    return {"P0": base, "P1": p1, "P2": p2}


def render(bundle: ObservableBundle, source_id: str) -> dict[str, str]:
    return build_prompts(render_prompt(bundle, source_id))


def sha(s: str) -> str:
    return hashlib.sha256(s.encode()).hexdigest()


def freeze_check() -> dict:
    """Confirm the P1 grounding block is byte-identical to frozen_v1; report all version hashes."""
    import json

    manifest = json.loads((FROZEN / "manifest.json").read_text())
    frozen_p1_sha = manifest["conditions"]["P1"]["delta_sha256"]
    ok_p1 = sha(P1_RULES) == frozen_p1_sha
    return {
        "p1_grounding_block_unchanged": ok_p1,
        "p1_grounding_sha256": sha(P1_RULES),
        "frozen_v1_p1_sha256": frozen_p1_sha,
        "base_v2_id_clause_sha256": sha(ID_CLAUSE),
        "p2_structured_citations_v2_sha256": sha(P2_CITATIONS_V2),
        "p2_structured_schema_patch_v2_sha256": sha(_MERGE_LINE_P2_V2),
        "note": ("P1 grounding block reused byte-identical from frozen_v1. Base gains the "
                 "answer-neutral id clause (all conditions). P2 uses a versioned structured "
                 "evidence_refs contract; the frozen_v1 free-text P2 contract is preserved untouched."),
    }
