"""Offline gates part 2: freeze-check, prompt rendering, task matrix, and cost estimate.

Zero API calls. Writes rendered prompts, the task matrix, and the cost estimate under
experiments/exp04-v0.2-generalization/. Run:
    uv run --locked python experiments/exp04-v0.2-generalization/gates_build.py
"""
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

from prompts_v2 import CONDITIONS, freeze_check, render, sha  # noqa: E402
from scenarios import build_all  # noqa: E402

from poc.observability import build_bundle  # noqa: E402
from poc.simulator import simulate  # noqa: E402

MODEL = "claude-sonnet-5"
MAX_TOKENS = 8192
OUT = HERE
# temperature is intentionally OMITTED (the model rejects it; the provider omits it) — matches Exp 03.

# Per-condition average OUTPUT tokens observed in Experiment 03 (18 calls each), used only to
# estimate cost. Input tokens are estimated from the rendered prompt length (~4 chars/token).
EXP03_OUT_AVG = {"P0": 665, "P1": 397, "P2": 425}
PRICE_IN_PER_M = 2.0
PRICE_OUT_PER_M = 10.0


def _fingerprint(prompt_sha: str) -> dict:
    # No temperature key — reflects exactly what is sent to claude-sonnet-5.
    return {"requested_model": MODEL, "provider": "anthropic", "max_tokens": MAX_TOKENS,
            "prompt_sha256": prompt_sha}


def main() -> int:
    fc = freeze_check()
    print("== Gate 5: freeze check ==")
    for k, v in fc.items():
        print(f"  {k}: {v}")
    if not fc["p1_grounding_block_unchanged"]:
        print("FAIL: P1 grounding block drifted from frozen_v1")
        return 1

    print("\n== Gate 6: render prompts + build task matrix ==")
    prompts_root = OUT / "prompts"
    for c in CONDITIONS:
        (prompts_root / c).mkdir(parents=True, exist_ok=True)

    matrix = []
    prompt_hashes: dict[str, str] = {}
    calls = 0
    cost = 0.0
    per_condition_calls = {c: 0 for c in CONDITIONS}

    for b in build_all():
        s = b.spec
        if s.twin_of is not None:
            continue  # twin shares the primary's identical prompt; no separate API cells
        sim = simulate(b.scenario)
        for lvl in s.levels:
            bundle = build_bundle(sim, lvl, set(s.partial_resolution_drop))
            prompts = render(bundle, s.probe_source_id)
            for c in CONDITIONS:
                text = prompts[c]
                psha = sha(text)
                fname = f"{s.scenario_id}_{lvl.value}.txt"
                (prompts_root / c / fname).write_text(text)
                prompt_hashes[f"{c}/{fname}"] = psha
                in_tok = -(-len(text) // 4)  # ceil(len/4)
                out_avg = EXP03_OUT_AVG[c]
                cell_cost = s.k * (in_tok / 1e6 * PRICE_IN_PER_M + out_avg / 1e6 * PRICE_OUT_PER_M)
                cost += cell_cost
                calls += s.k
                per_condition_calls[c] += s.k
                matrix.append({
                    "scenario_id": s.scenario_id, "group": s.group, "level": lvl.value,
                    "condition": c, "k": s.k, "probe_source_id": s.probe_source_id,
                    "reference_status": s.expected[lvl.value].status,
                    "reference_final_id": s.expected[lvl.value].final_id,
                    "reference_merge_target_id": s.expected[lvl.value].merge_target_id,
                    "merge_target_observable": s.expected[lvl.value].merge_target_observable,
                    "name_trap_at_minimal": s.name_trap_at_minimal,
                    "twin_id": s.twin_id,
                    "prompt_file": f"{c}/{fname}", "prompt_sha256": psha,
                    "fingerprint": _fingerprint(psha),
                    "est_input_tokens": in_tok, "est_output_tokens": out_avg,
                })

    combined = sha("".join(f"{k}:{v}" for k, v in sorted(prompt_hashes.items())))
    (OUT / "task_matrix.json").write_text(json.dumps(matrix, indent=2))
    (OUT / "prompt_manifest.json").write_text(json.dumps({
        "model": MODEL, "max_tokens": MAX_TOKENS, "temperature": "omitted (model rejects it)",
        "base_version": "base_v2 (frozen P0 render + answer-neutral id clause)",
        "p2_output_contract": "structured evidence_refs v2 (versioned; frozen_v1 free-text contract preserved)",
        "freeze_check": fc,
        "combined_prompt_sha256": combined,
        "n_prompt_files": len(prompt_hashes),
        "per_file_sha256": prompt_hashes,
    }, indent=2))

    cells = len(matrix)
    cost_est = {
        "model": MODEL, "pricing": "sonnet-5 $2/M input, $10/M output",
        "n_scenarios_primary": len({m["scenario_id"] for m in matrix}),
        "n_observable_task_conditions": cells // len(CONDITIONS),
        "n_cells_scenario_level_condition": cells,
        "total_calls": calls,
        "per_condition_calls": per_condition_calls,
        "k_general": 3, "k_calibration": 5,
        "estimated_cost_usd": round(cost, 2),
        "note": ("Input tokens estimated at ~4 chars/token from the rendered prompts; output tokens "
                 "from Experiment 03 per-condition averages. Counterfactual twin S11B adds 0 calls "
                 "(identical prompt to S11; scored under both hidden-truth framings)."),
    }
    (OUT / "cost_estimate.json").write_text(json.dumps(cost_est, indent=2))

    print(f"  rendered {len(prompt_hashes)} prompt files; combined sha256 {combined[:12]}")
    print(f"  matrix cells (scenario×level×condition): {cells}")
    print(f"  total calls (k=3 general, k=5 calibration): {calls}")
    print(f"  estimated cost: ${cost_est['estimated_cost_usd']}")
    print("\nALL BUILD GATES PASSED")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
