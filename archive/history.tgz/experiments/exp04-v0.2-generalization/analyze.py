"""Experiment 04 — analysis of the live v0.2 run.

Computes task-level (micro) AND scenario-level (macro) metrics, the three P2 evidence-chain
validity metrics, a failure-mode breakdown, paired evidence-transition accuracy, and applies
the PRE-REGISTERED verdict rule (unmodified). Writes analysis_summary.json and prints a report.

Zero API calls. Run after run_live.py:
    uv run --locked python experiments/exp04-v0.2-generalization/analyze.py
"""
from __future__ import annotations

import json
import statistics
import sys
from collections import defaultdict
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

from scenarios import build_all  # noqa: E402

SAMPLES = HERE / "samples"
CONDS = ("P0", "P1", "P2")
POSITIVE = {"PRESENT_UNDER_OTHER_ID", "WRONG_MERGE", "INGESTION_LOSS", "EXTRACTION_LOSS", "FILTERED_OUT"}

# Transition scenarios and the two bracketing levels (determinable level, first-UND level).
TRANSITION_BRACKET = {
    "S03": ("partial", "minimal"), "S04": ("partial", "minimal"),
    "S05": ("partial", "minimal"), "S06": ("partial", "minimal"),
    "S07": ("full", "partial"), "S15": ("full", "partial"),
}


def load_samples() -> list[dict]:
    out = []
    for p in SAMPLES.rglob("*.json"):
        out.append(json.loads(p.read_text()))
    return out


def _mean(xs: list[float]) -> float:
    return round(statistics.mean(xs), 4) if xs else 0.0


def micro(samples: list[dict]) -> dict:
    """Task-level pooled metrics per condition."""
    res = {}
    for c in CONDS:
        rows = [s for s in samples if s["condition"] == c]
        n = len(rows)
        und = [s for s in rows if s["reference"]["status"] == "UNDETERMINABLE"]
        det = [s for s in rows if s["reference"]["status"] != "UNDETERMINABLE"]
        status_acc = _mean([s["prediction"]["status_correct"] for s in rows])
        full_acc = _mean([s["prediction"]["full_correct"] for s in rows])
        malformed = sum(s["prediction"]["malformed"] for s in rows)
        unsup = _mean([1.0 if (not s["prediction"]["malformed"]
                               and s["prediction"]["predicted_status"] in POSITIVE) else 0.0 for s in und])
        abst = _mean([1.0 if s["prediction"]["predicted_status"] == "UNDETERMINABLE" else 0.0 for s in und])
        cpos_status = _mean([s["prediction"]["status_correct"] for s in det])
        cpos_full = _mean([s["prediction"]["full_correct"] for s in det])
        tin = sum(s["input_tokens"] or 0 for s in rows)
        tout = sum(s["output_tokens"] or 0 for s in rows)
        res[c] = {
            "n_samples": n, "status_accuracy": status_acc, "full_accuracy": full_acc,
            "malformed": malformed, "unsupported_positive_rate": unsup, "correct_abstention_rate": abst,
            "correct_positive_rate_status": cpos_status, "correct_positive_rate_full": cpos_full,
            "input_tokens": tin, "output_tokens": tout,
            "cost_usd": round(tin / 1e6 * 2 + tout / 1e6 * 10, 4),
        }
    return res


def macro(samples: list[dict]) -> dict:
    """Scenario-level metrics: compute per-scenario, then average across scenarios."""
    by_sc = defaultdict(lambda: defaultdict(list))  # scenario -> condition -> samples
    for s in samples:
        by_sc[s["scenario_id"]][s["condition"]].append(s)

    res = {}
    for c in CONDS:
        status_per_sc, full_per_sc, unsup_per_sc, abst_per_sc, cpos_per_sc = [], [], [], [], []
        for sc, conds in by_sc.items():
            rows = conds.get(c, [])
            if not rows:
                continue
            status_per_sc.append(_mean([r["prediction"]["status_correct"] for r in rows]))
            full_per_sc.append(_mean([r["prediction"]["full_correct"] for r in rows]))
            und = [r for r in rows if r["reference"]["status"] == "UNDETERMINABLE"]
            det = [r for r in rows if r["reference"]["status"] != "UNDETERMINABLE"]
            if und:
                unsup_per_sc.append(_mean([1.0 if (not r["prediction"]["malformed"]
                                    and r["prediction"]["predicted_status"] in POSITIVE) else 0.0 for r in und]))
                abst_per_sc.append(_mean([1.0 if r["prediction"]["predicted_status"] == "UNDETERMINABLE"
                                          else 0.0 for r in und]))
            if det:
                cpos_per_sc.append(_mean([r["prediction"]["full_correct"] for r in det]))
        res[c] = {
            "scenarios": len(status_per_sc),
            "status_accuracy_macro": _mean(status_per_sc),
            "full_accuracy_macro": _mean(full_per_sc),
            "unsupported_positive_rate_macro": _mean(unsup_per_sc),
            "correct_abstention_rate_macro": _mean(abst_per_sc),
            "correct_positive_rate_full_macro": _mean(cpos_per_sc),
            "n_scenarios_with_und": len(unsup_per_sc),
            "n_scenarios_with_det": len(cpos_per_sc),
        }
    return res


def transition_accuracy(samples: list[dict]) -> dict:
    """Per-scenario paired transition accuracy, macro-averaged. Pairs sample i across the two
    bracketing levels: transition-correct iff correct at BOTH (commit + abstain)."""
    idx = defaultdict(dict)  # (scenario, condition, level, sample) -> full_correct
    for s in samples:
        idx[(s["scenario_id"], s["condition"], s["level"])][s["sample"]] = s["prediction"]["full_correct"]
    res = {}
    for c in CONDS:
        per_sc = {}
        for sc, (det_lvl, und_lvl) in TRANSITION_BRACKET.items():
            det_map = idx.get((sc, c, det_lvl), {})
            und_map = idx.get((sc, c, und_lvl), {})
            shared = sorted(set(det_map) & set(und_map))
            if not shared:
                continue
            per_sc[sc] = _mean([1.0 if (det_map[i] and und_map[i]) else 0.0 for i in shared])
        res[c] = {"per_scenario": per_sc, "macro": _mean(list(per_sc.values()))}
    return res


def p2_validity(samples: list[dict]) -> dict:
    pos = [s for s in samples if s["condition"] == "P2" and s.get("chain_validity") is not None
           and s["prediction"]["predicted_status"] in POSITIVE]
    n = len(pos)
    def rate(key): return _mean([1.0 if s["chain_validity"][key] else 0.0 for s in pos])
    return {
        "positive_answers_scored": n,
        "status_evidence_validity": rate("status_evidence_validity"),
        "identifier_evidence_validity": rate("identifier_evidence_validity"),
        "full_evidence_validity": rate("full_evidence_validity"),
    }


def failure_modes(samples: list[dict]) -> dict:
    res = {}
    for c in CONDS:
        rows = [s for s in samples if s["condition"] == c]
        buckets = defaultdict(list)
        for s in rows:
            p = s["prediction"]
            ref = s["reference"]["status"]
            tag = f"{s['scenario_id']}:{s['level']}#{s['sample']}"
            if p["malformed"]:
                buckets["malformed"].append(tag)
                continue
            if p["full_correct"]:
                continue
            pred = p["predicted_status"]
            if ref == "UNDETERMINABLE" and pred in POSITIVE:
                buckets["unsupported_positive"].append(tag)
            elif ref != "UNDETERMINABLE" and pred == "UNDETERMINABLE":
                buckets["over_abstention"].append(tag)
            elif ref != "UNDETERMINABLE" and pred != ref and pred in POSITIVE:
                buckets["wrong_label"].append(tag)
            elif p["status_correct"] and not p["full_correct"]:
                buckets["wrong_identifier"].append(tag)
            else:
                buckets["other"].append(tag)
        res[c] = {k: {"count": len(v), "examples": v[:8]} for k, v in sorted(buckets.items())}
    return res


def verdict(macro_res: dict) -> dict:
    """PRE-REGISTERED rule (unmodified): generalizes iff, moving P0->P1 and P0->P2,
    (i) unsupported-positive macro DECREASES, (ii) correct-positive macro does NOT decrease,
    (iii) status-accuracy macro does NOT decrease. P2 also needs high full evidence validity."""
    p0 = macro_res["P0"]
    out = {}
    for c in ("P1", "P2"):
        cc = macro_res[c]
        i = cc["unsupported_positive_rate_macro"] < p0["unsupported_positive_rate_macro"]
        ii = cc["correct_positive_rate_full_macro"] >= p0["correct_positive_rate_full_macro"] - 1e-9
        iii = cc["status_accuracy_macro"] >= p0["status_accuracy_macro"] - 1e-9
        out[c] = {"reduces_unsupported_positive": i, "no_drop_in_correct_positive": ii,
                  "no_drop_in_status_accuracy": iii, "generalizes": bool(i and ii and iii)}
    return out


def main() -> int:
    samples = load_samples()
    if not samples:
        print("no samples found — run run_live.py first")
        return 1
    mic = micro(samples)
    mac = macro(samples)
    trans = transition_accuracy(samples)
    val = p2_validity(samples)
    fm = failure_modes(samples)
    vd = verdict(mac)

    total_cost = round(sum(mic[c]["cost_usd"] for c in CONDS), 4)
    summary = {
        "n_samples": len(samples), "total_cost_usd": total_cost,
        "task_level_micro": mic, "scenario_level_macro": mac,
        "transition_accuracy": trans, "p2_evidence_chain_validity": val,
        "failure_modes": fm, "verdict_preregistered": vd,
    }
    (HERE / "analysis_summary.json").write_text(json.dumps(summary, indent=2))

    print("=" * 70)
    print(f"samples={len(samples)}  total_cost=${total_cost}")
    print("\n-- TASK-LEVEL (micro) --")
    for c in CONDS:
        m = mic[c]
        print(f"  {c}: status={m['status_accuracy']} full={m['full_accuracy']} "
              f"unsup+={m['unsupported_positive_rate']} abstain={m['correct_abstention_rate']} "
              f"cpos_full={m['correct_positive_rate_full']} malformed={m['malformed']}")
    print("\n-- SCENARIO-LEVEL (macro; PRIMARY for generalization) --")
    for c in CONDS:
        m = mac[c]
        print(f"  {c}: status={m['status_accuracy_macro']} full={m['full_accuracy_macro']} "
              f"unsup+={m['unsupported_positive_rate_macro']} abstain={m['correct_abstention_rate_macro']} "
              f"cpos_full={m['correct_positive_rate_full_macro']}")
    print("\n-- TRANSITION (macro paired) --")
    for c in CONDS:
        print(f"  {c}: {trans[c]['macro']}  per_scenario={trans[c]['per_scenario']}")
    print("\n-- P2 EVIDENCE-CHAIN VALIDITY --")
    print(f"  {val}")
    print("\n-- FAILURE MODES --")
    for c in CONDS:
        print(f"  {c}: " + ", ".join(f"{k}={v['count']}" for k, v in fm[c].items()) or f"  {c}: none")
    print("\n-- PRE-REGISTERED VERDICT --")
    for c in ("P1", "P2"):
        print(f"  {c}: generalizes={vd[c]['generalizes']} {vd[c]}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
