"""Offline gates part 1: reference-generation, counterfactual hash, validation, baselines.

Zero API calls. Run:
    uv run --locked python experiments/exp04-v0.2-generalization/gates_core.py
"""
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

from scenarios import build_all, by_id, BuiltScenario  # noqa: E402

from poc.baselines import BASELINES  # noqa: E402
from poc.evaluator import evaluate_one  # noqa: E402
from poc.models import ArtifactState, Label, Observability, Prediction  # noqa: E402
from poc.observability import build_bundle  # noqa: E402
from poc.simulator import simulate  # noqa: E402
from poc.solver import solve  # noqa: E402

ORDER = [Observability.FULL, Observability.PARTIAL, Observability.MINIMAL]


def _sim_and_bundle(b: BuiltScenario, level: Observability):
    sim = simulate(b.scenario)
    return build_bundle(sim, level, set(b.spec.partial_resolution_drop))


def _observable_blob(bundle) -> str:
    payload = {
        "sources": bundle.sources,
        "final_dataset": bundle.final_dataset,
        "artifacts": {
            name: {"state": a.state.value, "complete_scopes": sorted(a.complete_scopes),
                   "rows": a.rows}
            for name, a in sorted(bundle.artifacts.items())
            if a.state is not ArtifactState.MISSING
        },
    }
    return json.dumps(payload, sort_keys=True)


class Gate:
    def __init__(self) -> None:
        self.failures: list[str] = []
        self.passes = 0

    def check(self, ok: bool, msg: str) -> None:
        if ok:
            self.passes += 1
        else:
            self.failures.append(msg)


def gate_reference(g: Gate) -> None:
    print("\n== Gate 1: reference-generation (solver == authored expected) ==")
    for b in build_all():
        s = b.spec
        for lvl in s.levels:
            bundle = _sim_and_bundle(b, lvl)
            ans = solve(bundle, s.probe_source_id)
            exp = s.expected[lvl.value]
            ok = (ans.status.value == exp.status
                  and ans.final_id == exp.final_id
                  and ans.merge_target_id == exp.merge_target_id
                  and ans.merge_target_observable == exp.merge_target_observable)
            g.check(ok, f"{s.scenario_id}:{lvl.value} solver={ans.status.value}/"
                        f"final={ans.final_id}/mt={ans.merge_target_id}/obs={ans.merge_target_observable} "
                        f"!= expected {exp.status}/{exp.final_id}/{exp.merge_target_id}/{exp.merge_target_observable}")
            flag = "ok" if ok else "FAIL"
            print(f"  [{flag}] {s.scenario_id}:{lvl.value:<7} -> {ans.status.value}"
                  + (f" final={ans.final_id}" if ans.final_id else "")
                  + (f" mt={ans.merge_target_id}(obs={ans.merge_target_observable})"
                     if ans.status is Label.WRONG_MERGE else ""))


def gate_counterfactual(g: Gate) -> None:
    print("\n== Gate 2: counterfactual hash (twin observable bundles are byte-identical) ==")
    reg = by_id()
    for b in build_all():
        if b.spec.twin_id is None:
            continue
        twin = reg[b.spec.twin_id]
        lvl = b.spec.levels[0]
        blob_a = _observable_blob(_sim_and_bundle(b, lvl))
        blob_b = _observable_blob(_sim_and_bundle(twin, lvl))
        ha, hb = hashlib.sha256(blob_a.encode()).hexdigest(), hashlib.sha256(blob_b.encode()).hexdigest()
        ok = ha == hb
        g.check(ok, f"{b.spec.scenario_id}/{b.spec.twin_id} observable {lvl.value} bundles differ: {ha[:12]} vs {hb[:12]}")
        # references must also match
        ra = solve(_sim_and_bundle(b, lvl), b.spec.probe_source_id).status
        rb = solve(_sim_and_bundle(twin, lvl), twin.spec.probe_source_id).status
        g.check(ra == rb, f"{b.spec.scenario_id}/{b.spec.twin_id} references differ: {ra.value} vs {rb.value}")
        print(f"  [{'ok' if ok else 'FAIL'}] {b.spec.scenario_id}=={b.spec.twin_id} @ {lvl.value}: "
              f"hash={ha[:12]} (ref {ra.value})")


def gate_validation(g: Gate) -> None:
    print("\n== Gate 3: per-scenario validation (no leak, monotone determinability) ==")
    banned = ("true_entity_id", "actual_outcome", "disappearance_reason", "is_wrong_merge", "merged_with")
    changed_scenarios = 0
    for b in build_all():
        sim = simulate(b.scenario)
        probe = b.spec.probe_source_id
        # no ground-truth leak in any evaluated level
        for lvl in b.spec.levels:
            blob = build_bundle(sim, lvl, set(b.spec.partial_resolution_drop)).model_dump_json()
            leak = next((t for t in banned if t in blob), None)
            g.check(leak is None, f"{b.spec.scenario_id}:{lvl.value} leaks ground-truth token {leak!r}")
        # monotone determinability across evaluated levels (full->partial->minimal)
        det_prev = True
        levels_sorted = [l for l in ORDER if l in b.spec.levels]
        statuses = set()
        for lvl in levels_sorted:
            ans = solve(build_bundle(sim, lvl, set(b.spec.partial_resolution_drop)), probe)
            statuses.add(ans.status)
            det = ans.status is not Label.UNDETERMINABLE
            g.check(not (det and not det_prev),
                    f"{b.spec.scenario_id}:{lvl.value} became determinable after being UND at a looser level")
            det_prev = det
        if len(statuses) > 1:
            changed_scenarios += 1
    print(f"  scenarios whose evidence-supported answer changes across levels: {changed_scenarios}")
    g.check(changed_scenarios >= 6, f"expected several level-transition scenarios, got {changed_scenarios}")


def _pred_json(p: Prediction) -> str:
    return json.dumps({"source_id": p.source_id, "status": p.status.value,
                       "final_id": p.final_id, "merge_target_id": p.merge_target_id})


def gate_baselines(g: Gate) -> None:
    print("\n== Gate 4: lineage-free baselines (name-trap fires wrong; strong-id solves controls) ==")
    for b in build_all():
        if b.spec.twin_of is not None:
            continue
        s = b.spec
        # name-trap: at minimal, name_similarity should fire a POSITIVE where the reference is UND
        if s.name_trap_at_minimal and Observability.MINIMAL in s.levels:
            bundle = _sim_and_bundle(b, Observability.MINIMAL)
            ref = solve(bundle, s.probe_source_id)
            pred = BASELINES["name_similarity"](bundle, s.probe_source_id)
            fired = pred.status is Label.PRESENT_UNDER_OTHER_ID
            g.check(ref.status is Label.UNDETERMINABLE and fired,
                    f"{s.scenario_id}: expected name_similarity to fire a wrong positive at minimal "
                    f"(ref={ref.status.value}, baseline={pred.status.value})")
            print(f"  [{'ok' if (ref.status is Label.UNDETERMINABLE and fired) else 'FAIL'}] "
                  f"{s.scenario_id}: name_similarity -> {pred.status.value} "
                  f"{pred.final_id or ''} (ref UND) — baseline error as designed")
        # positive controls: strong_id baseline solves them at minimal
        if s.group == "A" and s.expected.get("minimal") and s.expected["minimal"].status == "PRESENT_UNDER_OTHER_ID":
            bundle = _sim_and_bundle(b, Observability.MINIMAL)
            ref = solve(bundle, s.probe_source_id)
            pred = BASELINES["strong_id"](bundle, s.probe_source_id)
            rec = evaluate_one(f"{s.scenario_id}:minimal", ref, _pred_json(pred))
            g.check(rec.full_correct or s.probe_source_id.endswith("-P") and pred.status is Label.PRESENT_UNDER_OTHER_ID,
                    f"{s.scenario_id}: strong_id baseline failed the positive control at minimal")


def main() -> int:
    g = Gate()
    gate_reference(g)
    gate_counterfactual(g)
    gate_validation(g)
    gate_baselines(g)
    print("\n" + "=" * 60)
    if g.failures:
        print(f"FAILED {len(g.failures)} check(s):")
        for f in g.failures:
            print("  - " + f)
        return 1
    print(f"ALL {g.passes} CHECKS PASSED")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
