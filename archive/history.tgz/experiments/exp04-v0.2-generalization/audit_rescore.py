"""Offline audit: re-score preserved P2 responses with the corrected validator (v2).

Reads samples/ read-only (never modifies them or the frozen originals). Proves v2 is not
over-lenient (adversarial assertions), then re-scores all P2 positives and writes
corrected_evidence_validity.json. Zero API calls.
"""
from __future__ import annotations

import glob
import json
import sys
from collections import Counter
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

import validators as v1  # noqa: E402
import validators_v2 as v2  # noqa: E402
from scenarios import by_id  # noqa: E402

from poc.evaluator import parse_prediction  # noqa: E402
from poc.models import Label, Observability  # noqa: E402
from poc.observability import build_bundle  # noqa: E402
from poc.simulator import simulate  # noqa: E402
from poc.solver import solve  # noqa: E402

LV = {"full": Observability.FULL, "partial": Observability.PARTIAL, "minimal": Observability.MINIMAL}
POS = {"PRESENT_UNDER_OTHER_ID", "WRONG_MERGE", "INGESTION_LOSS", "EXTRACTION_LOSS", "FILTERED_OUT"}


def bundle_ref(sid: str, level: str):
    b = by_id()[sid]
    sim = simulate(b.scenario)
    bundle = build_bundle(sim, LV[level], set(b.spec.partial_resolution_drop))
    return bundle, solve(bundle, b.spec.probe_source_id)


# --------------------------------------------------------------------------------------
# Adversarial correctness assertions for v2 (must NOT pass bad citations)
# --------------------------------------------------------------------------------------
def assert_v2_not_overlenient() -> list[str]:
    out = []

    def ck(name, cond):
        out.append(f"[{'ok' if cond else 'FAIL'}] {name}")
        assert cond, name

    b01m, r01m = bundle_ref("S01", "minimal")
    # valid: strong-id share via real field registration_number
    good = [{"artifact": "source_records", "match": {"source_id": "S01-P", "registration_number": "07711234"}},
            {"artifact": "final_dataset", "match": {"final_id": "ENT-01", "strong_id": "registry:UK/07711234"}}]
    ck("v2 accepts strong-id share via registration_number",
       v2.status_evidence_validity(b01m, r01m, Label.PRESENT_UNDER_OTHER_ID, good))
    # name-only still invalid
    nameonly = [{"artifact": "final_dataset", "match": {"canonical_name": "Halcyon Foods"}}]
    ck("v2 rejects name-only citation",
       not v2.status_evidence_validity(b01m, r01m, Label.PRESENT_UNDER_OTHER_ID, nameonly))
    # genuine weak citation: final strong id + 'ingested', no source strong-id link -> insufficient
    weak = [{"artifact": "final_dataset", "match": {"final_id": "ENT-01", "strong_id": "registry:UK/07711234"}},
            {"artifact": "ingestion_manifest", "match": {"source_id": "S01-P", "status": "ingested"}}]
    ck("v2 keeps genuine weak citation invalid (no source strong-id link)",
       not v2.evidence_sufficiency(b01m, r01m, Label.PRESENT_UNDER_OTHER_ID, weak))

    b03m, r03m = bundle_ref("S03", "minimal")  # resolution_map is MISSING here
    missingcite = [{"artifact": "resolution_map", "match": {"source_id": "S03-P", "canonical_id": "C3"}},
                   {"artifact": "final_dataset", "match": {"final_id": "ENT-03", "canonical_id": "C3"}}]
    ck("v2 integrity rejects MISSING-artifact citation",
       not v2.citation_integrity(b03m, missingcite))

    b13, r13 = bundle_ref("S13", "full")
    good13 = [{"artifact": "merge_decision_log", "match": {"canonical_id": "C13"}},
              {"artifact": "final_dataset", "match": {"final_id": "ENT-13", "canonical_id": "C13"}}]
    ck("v2 identifier rejects canonical id as merge target",
       not v2.identifier_evidence_validity(b13, r13, Label.WRONG_MERGE, None, "C13", good13))
    ck("v2 identifier accepts public final id",
       v2.identifier_evidence_validity(b13, r13, Label.WRONG_MERGE, None, "ENT-13", good13))

    b04, r04 = bundle_ref("S04", "full")
    comp = [{"artifact": "ingestion_manifest", "match": {"guaranteed_complete_for": "B1"}}]
    ck("v2 accepts completeness-scope citation for INGESTION_LOSS",
       v2.status_evidence_validity(b04, r04, Label.INGESTION_LOSS, comp))
    bogus_comp = [{"artifact": "ingestion_manifest", "match": {"guaranteed_complete_for": "B9"}}]
    ck("v2 rejects a completeness scope the artifact does not guarantee",
       not v2.citation_integrity(b04, bogus_comp))
    return out


# --------------------------------------------------------------------------------------
# Re-score
# --------------------------------------------------------------------------------------
def rescore() -> dict:
    samples = [json.load(open(f)) for f in
               glob.glob(str(HERE / "samples" / "**" / "P2" / "*.json"), recursive=True)]
    pos = [s for s in samples if s["prediction"]["predicted_status"] in POS]

    rows = []
    for s in pos:
        bundle, ref = bundle_ref(s["scenario_id"], s["level"])
        pred = parse_prediction(s["text"]).prediction
        refs = s.get("evidence_refs") or []
        st = pred.status
        r = {
            "cell": f'{s["scenario_id"]}:{s["level"]}#{s["sample"]}',
            "pred_status": st.value, "full_correct": s["prediction"]["full_correct"],
            "v1_status_valid": s["chain_validity"]["status_evidence_validity"],
            "v2_integrity": v2.citation_integrity(bundle, refs),
            "v2_sufficiency": v2.evidence_sufficiency(bundle, ref, st, refs),
            "v2_status_valid": v2.status_evidence_validity(bundle, ref, st, refs),
            "v2_identifier_valid": v2.identifier_evidence_validity(
                bundle, ref, st, pred.final_id, pred.merge_target_id, refs),
            "v2_full_valid": v2.full_evidence_validity(
                bundle, ref, st, pred.final_id, pred.merge_target_id, refs),
        }
        rows.append(r)

    n = len(rows)
    def rate(key): return round(sum(r[key] for r in rows) / n, 4) if n else 0.0
    flipped = [r["cell"] for r in rows if not r["v1_status_valid"] and r["v2_status_valid"]]
    still_invalid = [r["cell"] for r in rows if not r["v2_status_valid"]]
    summary = {
        "positive_answers_scored": n,
        "v1_status_evidence_validity": round(sum(r["v1_status_valid"] for r in rows) / n, 4),
        "v2_citation_integrity": rate("v2_integrity"),
        "v2_evidence_sufficiency": rate("v2_sufficiency"),
        "v2_status_evidence_validity": rate("v2_status_valid"),
        "v2_identifier_evidence_validity": rate("v2_identifier_valid"),
        "v2_full_evidence_validity": rate("v2_full_valid"),
        "flipped_false_negatives_fixed": sorted(flipped),
        "n_flipped": len(flipped),
        "still_invalid_after_v2": sorted(still_invalid),
        "all_scored_answers_were_full_correct": all(r["full_correct"] for r in rows),
        "per_answer": sorted(rows, key=lambda r: r["cell"]),
    }
    return summary


def test_v2_not_overlenient():
    assert_v2_not_overlenient()


def test_rescore_integrity_and_remaining_invalids():
    s = rescore()
    assert s["v2_citation_integrity"] == 1.0
    assert s["all_scored_answers_were_full_correct"] is True
    assert s["still_invalid_after_v2"] == ["S01:minimal#3", "S14:minimal#2"]
    assert s["n_flipped"] == 10


def main() -> int:
    print("== v2 adversarial correctness assertions ==")
    for line in assert_v2_not_overlenient():
        print("  " + line)
    print("\n== re-score preserved P2 positives with v2 ==")
    summary = rescore()
    (HERE / "corrected_evidence_validity.json").write_text(json.dumps(summary, indent=2))
    for k in ("positive_answers_scored", "v1_status_evidence_validity", "v2_citation_integrity",
              "v2_evidence_sufficiency", "v2_status_evidence_validity",
              "v2_identifier_evidence_validity", "v2_full_evidence_validity",
              "n_flipped", "still_invalid_after_v2", "all_scored_answers_were_full_correct"):
        print(f"  {k}: {summary[k]}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
