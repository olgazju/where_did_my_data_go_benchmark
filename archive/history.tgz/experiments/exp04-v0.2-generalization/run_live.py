"""Experiment 04 — LIVE run of the pre-registered v0.2 generalization matrix.

Executes the 321-call matrix built by gates_build.py. Resumable, preserves everything, and
enforces a hard spending guardrail. Prompts / scenarios / reference labels / evaluation rules
are FROZEN — this script never modifies them.

Usage (key passed inline as an env var; never written to disk):
    ANTHROPIC_API_KEY=... uv run --locked python experiments/exp04-v0.2-generalization/run_live.py

Guardrails:
  * BUDGET_USD hard cap on cumulative real cost (default 5.0). Stops before it is exceeded.
  * MAX_CONSECUTIVE_FAILURES consecutive API errors -> stop and report.
"""
from __future__ import annotations

import json
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

from prompts_v2 import render  # noqa: E402  (used only to re-verify prompt hash integrity)
from scenarios import by_id  # noqa: E402
from validators import (  # noqa: E402
    full_evidence_validity,
    identifier_evidence_validity,
    status_evidence_validity,
)

from poc.evaluator import evaluate_one, parse_prediction  # noqa: E402
from poc.models import Label, Observability  # noqa: E402
from poc.observability import build_bundle  # noqa: E402
from poc.provider.anthropic import AnthropicProvider  # noqa: E402
from poc.provider.base import LLMRequest  # noqa: E402
from poc.simulator import simulate  # noqa: E402
from poc.solver import solve  # noqa: E402

MODEL = "claude-sonnet-5"
MAX_TOKENS = 8192
BUDGET_USD = 5.0
MAX_CONSECUTIVE_FAILURES = 3
PRICE_IN, PRICE_OUT = 2.0 / 1e6, 10.0 / 1e6
LEVEL = {"full": Observability.FULL, "partial": Observability.PARTIAL, "minimal": Observability.MINIMAL}

SAMPLES = HERE / "samples"
FAILURES = HERE / "failures"


class Budget:
    def __init__(self) -> None:
        self.cost = 0.0
        self.calls = 0

    def add(self, in_tok: int | None, out_tok: int | None) -> None:
        self.cost += (in_tok or 0) * PRICE_IN + (out_tok or 0) * PRICE_OUT
        self.calls += 1


def _ref_and_bundle(scenario_id: str, level: str):
    b = by_id()[scenario_id]
    sim = simulate(b.scenario)
    bundle = build_bundle(sim, LEVEL[level], set(b.spec.partial_resolution_drop))
    ref = solve(bundle, b.spec.probe_source_id)
    return ref, bundle, b.spec.probe_source_id


def _parse_refs(text: str):
    if "{" not in text:
        return None
    try:
        obj = json.loads(text[text.find("{"): text.rfind("}") + 1])
    except Exception:  # noqa: BLE001
        return None
    refs = obj.get("evidence_refs")
    return refs if isinstance(refs, list) else None


def _completed(cell: dict, i: int) -> Path:
    return SAMPLES / f"{cell['scenario_id']}_{cell['level']}" / cell["condition"] / f"{i:02d}.json"


def run() -> int:
    matrix = json.loads((HERE / "task_matrix.json").read_text())
    provider = AnthropicProvider(model=MODEL)

    # count how many samples remain
    todo = sum(cell["k"] - sum(_completed(cell, i).exists() for i in range(1, cell["k"] + 1))
               for cell in matrix)
    print(f"matrix cells: {len(matrix)}  samples remaining: {todo}  budget: ${BUDGET_USD}")
    if todo == 0:
        print("nothing to do — all samples already present")
        return 0

    provider.preflight()
    print(f"preflight ok: {MODEL}")

    budget = Budget()
    consecutive_failures = 0

    for cell in matrix:
        ref, bundle, probe = _ref_and_bundle(cell["scenario_id"], cell["level"])
        prompt = (HERE / "prompts" / cell["prompt_file"]).read_text()
        outdir = SAMPLES / f"{cell['scenario_id']}_{cell['level']}" / cell["condition"]
        outdir.mkdir(parents=True, exist_ok=True)

        for i in range(1, cell["k"] + 1):
            path = _completed(cell, i)
            if path.exists():
                continue

            if budget.cost >= BUDGET_USD:
                print(f"\n!! BUDGET GUARDRAIL: cumulative ${budget.cost:.3f} >= ${BUDGET_USD}. Stopping.")
                _write_progress(matrix, budget, stopped="budget")
                return 2

            try:
                resp = provider.complete(LLMRequest(model=MODEL, max_tokens=MAX_TOKENS,
                                                    temperature=0.0, prompt=prompt))
            except Exception as e:  # noqa: BLE001
                consecutive_failures += 1
                FAILURES.mkdir(parents=True, exist_ok=True)
                (FAILURES / f"{cell['scenario_id']}_{cell['level']}_{cell['condition']}_{i:02d}.json").write_text(
                    json.dumps({"cell": cell, "sample": i, "error": str(e),
                                "consecutive_failures": consecutive_failures}, indent=2))
                print(f"  FAIL {cell['scenario_id']}:{cell['level']}:{cell['condition']}#{i}: {e}")
                if consecutive_failures >= MAX_CONSECUTIVE_FAILURES:
                    print(f"\n!! {MAX_CONSECUTIVE_FAILURES} consecutive API failures. Stopping.")
                    _write_progress(matrix, budget, stopped="failures")
                    return 3
                time.sleep(2)
                continue

            consecutive_failures = 0
            budget.add(resp.input_tokens, resp.output_tokens)

            rec = evaluate_one(f"{cell['scenario_id']}:{cell['level']}", ref, resp.text)
            refs = _parse_refs(resp.text) if cell["condition"] == "P2" else None
            validity = None
            if cell["condition"] == "P2" and not rec.malformed:
                pred = parse_prediction(resp.text).prediction
                if pred is not None:
                    rl = refs or []
                    validity = {
                        "status_evidence_validity": status_evidence_validity(bundle, ref, pred.status, rl),
                        "identifier_evidence_validity": identifier_evidence_validity(
                            bundle, ref, pred.status, pred.final_id, pred.merge_target_id, rl),
                        "full_evidence_validity": full_evidence_validity(
                            bundle, ref, pred.status, pred.final_id, pred.merge_target_id, rl),
                    }

            # integrity: the prompt we sent must match the frozen matrix hash
            assert cell["prompt_sha256"] == __import__("hashlib").sha256(prompt.encode()).hexdigest(), \
                "prompt hash drift — aborting to preserve pre-registration"

            path.write_text(json.dumps({
                "scenario_id": cell["scenario_id"], "group": cell["group"], "level": cell["level"],
                "condition": cell["condition"], "sample": i, "probe_source_id": probe,
                "reference": {"status": ref.status.value, "final_id": ref.final_id,
                              "merge_target_id": ref.merge_target_id,
                              "merge_target_observable": ref.merge_target_observable},
                "fingerprint": cell["fingerprint"],
                "request_params": resp.request_params,  # exactly what was sent (no temperature for sonnet)
                "model_returned": resp.model,
                "prediction": rec.model_dump(mode="json"),
                "evidence_refs": refs, "chain_validity": validity,
                "input_tokens": resp.input_tokens, "output_tokens": resp.output_tokens,
                "text": resp.text, "raw": resp.raw,
            }, indent=2, default=str))
            print(f"  {cell['condition']} {cell['scenario_id']}:{cell['level']:<7}#{i} "
                  f"ref={ref.status.value:<22} pred={rec.predicted_status} full={rec.full_correct}"
                  + (f" valid={validity['full_evidence_validity']}" if validity else "")
                  + f"  [${budget.cost:.3f}, {budget.calls} calls]")

    _write_progress(matrix, budget, stopped=None)
    print(f"\nDONE. calls={budget.calls}  real_cost=${budget.cost:.3f}")
    return 0


def _write_progress(matrix, budget: Budget, stopped: str | None) -> None:
    done = sum(1 for cell in matrix for i in range(1, cell["k"] + 1) if _completed(cell, i).exists())
    total = sum(cell["k"] for cell in matrix)
    (HERE / "run_progress.json").write_text(json.dumps({
        "samples_completed": done, "samples_total": total,
        "calls_this_run": budget.calls, "real_cost_this_run_usd": round(budget.cost, 4),
        "stopped_reason": stopped, "budget_usd": BUDGET_USD,
    }, indent=2))


if __name__ == "__main__":
    raise SystemExit(run())
