"""Deterministic tests for the consolidated official benchmark (P2 only, validator v2).

    uv run --locked pytest experiments/exp04-v0.2-generalization/test_benchmark_official.py
"""
from __future__ import annotations

import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

import benchmark  # noqa: E402
import prompts_v2  # noqa: E402
import validators_v2  # noqa: E402


def test_official_prompt_is_p2():
    assert benchmark.OFFICIAL_PROMPT == "P2"


def test_official_validator_is_v2():
    # the benchmark's official validator is exactly validators_v2 (not v1)
    assert benchmark.official_validator is validators_v2


def test_matrix_is_single_condition_p2_only():
    cfg = benchmark.load_config(None)
    matrix = benchmark.build_matrix(cfg)
    assert matrix, "empty matrix"
    assert {c["condition"] for c in matrix} == {"P2"}, "official path must use only P2"


def test_official_render_matches_existing_v0_2_p2_byte_identical():
    cfg = benchmark.load_config(None)
    matrix = benchmark.build_matrix(cfg)
    ok, mism = benchmark.verify_prompts_match_existing(matrix)
    assert ok, f"official P2 render differs from existing v0.2 P2 prompts: {mism}"


def test_official_prompt_contains_the_three_frozen_components():
    # evidence-grounding block (frozen P1), id clause, and structured evidence_refs — unchanged
    b = benchmark.official_scenarios()[0]
    from poc.observability import build_bundle
    from poc.simulator import simulate
    from poc.models import Observability
    bundle = build_bundle(simulate(b.scenario), Observability.FULL, set(b.spec.partial_resolution_drop))
    prompt = benchmark.render_official(bundle, b.spec.probe_source_id)
    assert prompts_v2.P1_RULES in prompt, "grounding block missing"
    assert prompts_v2.ID_CLAUSE in prompt, "canonical-vs-final id clause missing"
    assert "evidence_refs" in prompt and "artifact" in prompt, "structured evidence_refs missing"


def test_p0_p1_preserved_for_reproducibility():
    # P0/P1 still available in prompts_v2, but not part of the official path
    b = benchmark.official_scenarios()[0]
    from poc.observability import build_bundle
    from poc.simulator import simulate
    from poc.models import Observability
    bundle = build_bundle(simulate(b.scenario), Observability.FULL, set(b.spec.partial_resolution_drop))
    conds = prompts_v2.render(bundle, b.spec.probe_source_id)
    assert set(conds) == {"P0", "P1", "P2"}
    # the frozen grounding block is unchanged
    assert prompts_v2.freeze_check()["p1_grounding_block_unchanged"] is True
