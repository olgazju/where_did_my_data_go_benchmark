"""Unit tests for the structured evidence_refs validators (offline, no LLM).

Runnable directly or via pytest:
    uv run --locked python experiments/exp04-v0.2-generalization/test_validators.py
    uv run --locked pytest experiments/exp04-v0.2-generalization/test_validators.py
"""
from __future__ import annotations

import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

from scenarios import by_id  # noqa: E402
from validators import (  # noqa: E402
    full_evidence_validity,
    identifier_evidence_validity,
    status_evidence_validity,
)

from poc.models import Label, Observability  # noqa: E402
from poc.observability import build_bundle  # noqa: E402
from poc.simulator import simulate  # noqa: E402
from poc.solver import solve  # noqa: E402

FULL, PARTIAL, MINIMAL = Observability.FULL, Observability.PARTIAL, Observability.MINIMAL


def _bundle(sid: str, level: Observability):
    b = by_id()[sid]
    sim = simulate(b.scenario)
    return build_bundle(sim, level, set(b.spec.partial_resolution_drop)), b.spec.probe_source_id


def _sv(bundle, ref, status, refs):
    return status_evidence_validity(bundle, ref, status, refs)


def _iv(bundle, ref, status, fid, mt, refs):
    return identifier_evidence_validity(bundle, ref, status, fid, mt, refs)


def _fv(bundle, ref, status, fid, mt, refs):
    return full_evidence_validity(bundle, ref, status, fid, mt, refs)


CASES: list[tuple[str, bool]] = []


def record(name: str, ok: bool) -> None:
    CASES.append((name, ok))
    print(f"  [{'ok' if ok else 'FAIL'}] {name}")


def test_present_strong_id_valid():
    bundle, probe = _bundle("S01", MINIMAL)
    ref = solve(bundle, probe)
    refs = [
        {"artifact": "source_records", "match": {"source_id": "S01-P", "strong_id": "registry:UK/07711234"}},
        {"artifact": "final_dataset", "match": {"final_id": "ENT-01", "strong_id": "registry:UK/07711234"}},
    ]
    assert _sv(bundle, ref, Label.PRESENT_UNDER_OTHER_ID, refs)
    assert _iv(bundle, ref, Label.PRESENT_UNDER_OTHER_ID, "ENT-01", None, refs)
    assert _fv(bundle, ref, Label.PRESENT_UNDER_OTHER_ID, "ENT-01", None, refs)


def test_present_name_only_invalid():
    bundle, probe = _bundle("S01", MINIMAL)
    ref = solve(bundle, probe)
    refs = [{"artifact": "final_dataset", "match": {"canonical_name": "Halcyon Foods"}}]  # name-only
    assert not _sv(bundle, ref, Label.PRESENT_UNDER_OTHER_ID, refs)
    assert not _fv(bundle, ref, Label.PRESENT_UNDER_OTHER_ID, "ENT-01", None, refs)


def test_present_via_map_valid_full_but_missing_at_minimal():
    # S03 present via resolution map at full; the same citation is ungrounded at minimal (map MISSING).
    full, probe = _bundle("S03", FULL)
    ref_full = solve(full, probe)
    refs = [
        {"artifact": "resolution_map", "match": {"source_id": "S03-P", "canonical_id": "C3"}},
        {"artifact": "final_dataset", "match": {"final_id": "ENT-03", "canonical_id": "C3"}},
    ]
    assert _fv(full, ref_full, Label.PRESENT_UNDER_OTHER_ID, "ENT-03", None, refs)
    minimal, _ = _bundle("S03", MINIMAL)
    ref_min = solve(minimal, probe)  # UNDETERMINABLE
    # Citing the (now MISSING) resolution_map to claim PRESENT is not grounded.
    assert not _sv(minimal, ref_min, Label.PRESENT_UNDER_OTHER_ID, refs)


def test_wrong_merge_target_observable_valid_and_canonical_trap():
    bundle, probe = _bundle("S13", FULL)
    ref = solve(bundle, probe)
    good = [
        {"artifact": "merge_decision_log", "match": {"canonical_id": "C13"}},
        {"artifact": "source_records", "match": {"source_id": "S13-P", "strong_id": "registry:US-WA/3320900"}},
        {"artifact": "final_dataset", "match": {"final_id": "ENT-13", "canonical_id": "C13"}},
    ]
    assert _sv(bundle, ref, Label.WRONG_MERGE, good)
    assert _iv(bundle, ref, Label.WRONG_MERGE, None, "ENT-13", good)
    assert _fv(bundle, ref, Label.WRONG_MERGE, None, "ENT-13", good)
    # Reporting the internal canonical id C13 instead of the public ENT-13 fails identifier validity.
    assert not _iv(bundle, ref, Label.WRONG_MERGE, None, "C13", good)


def test_wrong_merge_target_null_valid_and_bogus_target_invalid():
    bundle, probe = _bundle("S08", FULL)
    ref = solve(bundle, probe)  # WRONG_MERGE, target null
    refs = [
        {"artifact": "merge_decision_log", "match": {"canonical_id": "C8"}},
        {"artifact": "source_records", "match": {"source_id": "S08-P", "strong_id": "registry:US-MA/7712300"}},
    ]
    assert _sv(bundle, ref, Label.WRONG_MERGE, refs)
    assert _iv(bundle, ref, Label.WRONG_MERGE, None, None, refs)      # null target is correct
    assert not _iv(bundle, ref, Label.WRONG_MERGE, None, "ENT-08C", refs)  # asserting a target is a guess


def test_ingestion_loss_valid_and_wrong_shape_invalid():
    bundle, probe = _bundle("S04", FULL)
    ref = solve(bundle, probe)
    good = [{"artifact": "ingestion_manifest", "match": {"batch": "B1"}}]  # (probe absent within a complete batch)
    assert _sv(bundle, ref, Label.INGESTION_LOSS, good)
    assert _fv(bundle, ref, Label.INGESTION_LOSS, None, None, good)
    wrong = [{"artifact": "final_dataset", "match": {"final_id": "ENT-04D"}}]  # cites the wrong artifact
    assert not _sv(bundle, ref, Label.INGESTION_LOSS, wrong)


def test_abstention_is_status_valid_with_empty_refs():
    bundle, probe = _bundle("S09", MINIMAL)
    ref = solve(bundle, probe)  # UNDETERMINABLE
    assert _sv(bundle, ref, Label.UNDETERMINABLE, [])
    assert _iv(bundle, ref, Label.UNDETERMINABLE, None, None, [])
    assert _fv(bundle, ref, Label.UNDETERMINABLE, None, None, [])


def main() -> int:
    print("== validators unit tests ==")
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_") and callable(v)]
    failed = 0
    for fn in fns:
        try:
            fn()
            record(fn.__name__, True)
        except AssertionError as e:  # noqa: PERF203
            record(fn.__name__, False)
            print(f"       assertion failed: {e}")
            failed += 1
    print("=" * 60)
    print(f"{len(fns) - failed}/{len(fns)} validator tests passed")
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
