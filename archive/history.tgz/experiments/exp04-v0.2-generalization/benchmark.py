"""Official 'Where Did My Data Go?' v0.2 benchmark — standard execution path.

Consolidated around a SINGLE official prompt (P2) and the v2 evidence validator. There is NO
prompt-condition selection: P0/P1 are retained in `prompts_v2.py` only for historical
reproducibility and are not part of this path.

The official prompt is exactly the v0.2 P2 render (evidence-grounding block + canonical-vs-final
id clause + structured evidence_refs); its wording is unchanged here. The official validator is
`validators_v2`.

Standard commands (offline build makes ZERO API calls):
    uv run --locked python experiments/exp04-v0.2-generalization/benchmark.py build
    ANTHROPIC_API_KEY=... uv run --locked python experiments/exp04-v0.2-generalization/benchmark.py run
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[1]
sys.path.insert(0, str(HERE))

import prompts_v2  # noqa: E402
import validators_v2 as official_validator  # noqa: E402  (the official evidence validator)
from scenarios import build_all  # noqa: E402

from poc.models import Observability  # noqa: E402
from poc.observability import build_bundle  # noqa: E402
from poc.simulator import simulate  # noqa: E402
from poc.solver import solve  # noqa: E402

OFFICIAL_PROMPT = "P2"  # single official prompt; not user-selectable
LEVEL = {"full": Observability.FULL, "partial": Observability.PARTIAL, "minimal": Observability.MINIMAL}
DEFAULT_CONFIG = REPO / "configs" / "benchmark.yaml"
EXISTING_P2_DIR = HERE / "prompts" / "P2"  # the P2 prompts used in the Exp-04 run


def load_config(path: str | None) -> dict:
    import yaml
    p = Path(path) if path else DEFAULT_CONFIG
    data = {}
    if p.exists():
        data = yaml.safe_load(p.read_text()) or {}
    return {
        "model": data.get("model", "claude-sonnet-5"),
        "max_tokens": data.get("max_tokens", 8192),
        "k_general": data.get("k_general", 3),
        "k_calibration": data.get("k_calibration", 5),
        # prompt + validator are FIXED (official) — deliberately not read from config.
        "prompt": OFFICIAL_PROMPT,
        "validator": "v2",
    }


def official_scenarios():
    """The 15 primary scenarios (excludes the counterfactual twin, which shares a prompt)."""
    return [b for b in build_all() if b.spec.twin_of is None]


def render_official(bundle, source_id: str) -> str:
    """The single official prompt for a (bundle, record) — the P2 render, wording unchanged."""
    return prompts_v2.render(bundle, source_id)[OFFICIAL_PROMPT]


def _sha(s: str) -> str:
    return hashlib.sha256(s.encode()).hexdigest()


def build_matrix(cfg: dict) -> list[dict]:
    matrix = []
    for b in official_scenarios():
        s = b.spec
        sim = simulate(b.scenario)
        for lvl in s.levels:
            bundle = build_bundle(sim, LEVEL[lvl.value], set(s.partial_resolution_drop))
            prompt = render_official(bundle, s.probe_source_id)
            matrix.append({
                "scenario_id": s.scenario_id, "group": s.group, "level": lvl.value,
                "condition": OFFICIAL_PROMPT, "k": s.k, "probe_source_id": s.probe_source_id,
                "reference_status": s.expected[lvl.value].status,
                "reference_final_id": s.expected[lvl.value].final_id,
                "reference_merge_target_id": s.expected[lvl.value].merge_target_id,
                "merge_target_observable": s.expected[lvl.value].merge_target_observable,
                "prompt_file": f"P2/{s.scenario_id}_{lvl.value}.txt",
                "prompt_sha256": _sha(prompt),
                "fingerprint": {"requested_model": cfg["model"], "provider": "anthropic",
                                "max_tokens": cfg["max_tokens"], "prompt_sha256": _sha(prompt)},
            })
    return matrix


def verify_prompts_match_existing(matrix: list[dict]) -> tuple[bool, list[str]]:
    """Requirement 6: the official P2 render == the existing v0.2 P2 prompts (byte-identical)."""
    mismatches = []
    for cell in matrix:
        b = next(x for x in official_scenarios() if x.spec.scenario_id == cell["scenario_id"])
        sim = simulate(b.scenario)
        bundle = build_bundle(sim, LEVEL[cell["level"]], set(b.spec.partial_resolution_drop))
        rendered = render_official(bundle, b.spec.probe_source_id)
        existing = (HERE / "prompts" / cell["prompt_file"])
        if not existing.exists() or existing.read_text() != rendered:
            mismatches.append(cell["prompt_file"])
    return (not mismatches), mismatches


def cmd_build(args: argparse.Namespace) -> int:
    cfg = load_config(args.config)
    print("== Official v0.2 benchmark — offline build ==")
    print(f"  prompt: {cfg['prompt']} (single official prompt; no condition selection)")
    print(f"  validator: validators_{cfg['validator']} (official)")
    print(f"  model: {cfg['model']}  max_tokens: {cfg['max_tokens']}  temperature: omitted")

    # freeze integrity: the grounding block is byte-identical to frozen_v1
    fc = prompts_v2.freeze_check()
    assert fc["p1_grounding_block_unchanged"], "grounding block drifted from frozen_v1"
    print(f"  freeze check: P1 grounding block unchanged (sha {fc['p1_grounding_sha256'][:12]})")

    matrix = build_matrix(cfg)

    # reference-generation still holds (solver == authored expected)
    ref_ok = 0
    for b in official_scenarios():
        sim = simulate(b.scenario)
        for lvl in b.spec.levels:
            ans = solve(build_bundle(sim, LEVEL[lvl.value], set(b.spec.partial_resolution_drop)),
                        b.spec.probe_source_id)
            exp = b.spec.expected[lvl.value]
            assert (ans.status.value == exp.status and ans.final_id == exp.final_id
                    and ans.merge_target_id == exp.merge_target_id
                    and ans.merge_target_observable == exp.merge_target_observable), \
                f"reference drift at {b.spec.scenario_id}:{lvl.value}"
            ref_ok += 1
    print(f"  reference-generation: {ref_ok}/{ref_ok} cells match authored expected")

    ok, mism = verify_prompts_match_existing(matrix)
    assert ok, f"official P2 render differs from existing v0.2 P2 prompts: {mism}"
    print(f"  prompt verification: official P2 == existing v0.2 P2 for all {len(matrix)} cells (byte-identical)")

    calls = sum(c["k"] for c in matrix)
    (HERE / "official_task_matrix.json").write_text(json.dumps(matrix, indent=2))
    print(f"  wrote official_task_matrix.json: {len(matrix)} cells, {calls} calls "
          f"(k_general={cfg['k_general']}, k_calibration={cfg['k_calibration']})")
    print("\nStandard execution command (live run needs an API key):")
    print("  ANTHROPIC_API_KEY=... uv run --locked python "
          "experiments/exp04-v0.2-generalization/benchmark.py run")
    print("\nOFFLINE BUILD OK — no API calls made.")
    return 0


def cmd_run(args: argparse.Namespace) -> int:
    """Live P2-only benchmark run (resumable). Requires ANTHROPIC_API_KEY. Not invoked offline."""
    import os
    if not os.environ.get("ANTHROPIC_API_KEY"):
        raise SystemExit("ANTHROPIC_API_KEY not set — the live benchmark run needs a key.")
    cfg = load_config(args.config)
    from poc.evaluator import evaluate_one, parse_prediction
    from poc.provider.anthropic import AnthropicProvider
    from poc.provider.base import LLMRequest

    matrix = build_matrix(cfg)
    provider = AnthropicProvider(model=cfg["model"])
    provider.preflight()
    out = HERE / "benchmark_run" / "samples"
    for cell in matrix:
        b = next(x for x in official_scenarios() if x.spec.scenario_id == cell["scenario_id"])
        sim = simulate(b.scenario)
        bundle = build_bundle(sim, LEVEL[cell["level"]], set(b.spec.partial_resolution_drop))
        ref = solve(bundle, b.spec.probe_source_id)
        prompt = render_official(bundle, b.spec.probe_source_id)
        d = out / f"{cell['scenario_id']}_{cell['level']}"
        d.mkdir(parents=True, exist_ok=True)
        for i in range(1, cell["k"] + 1):
            path = d / f"{i:02d}.json"
            if path.exists():
                continue
            resp = provider.complete(LLMRequest(model=cfg["model"], max_tokens=cfg["max_tokens"],
                                                temperature=0.0, prompt=prompt))
            rec = evaluate_one(f"{cell['scenario_id']}:{cell['level']}", ref, resp.text)
            pred = parse_prediction(resp.text).prediction
            refs = None
            validity = None
            if not rec.malformed and pred is not None:
                obj = json.loads(resp.text[resp.text.find("{"): resp.text.rfind("}") + 1])
                refs = obj.get("evidence_refs") if isinstance(obj.get("evidence_refs"), list) else []
                validity = {
                    "citation_integrity": official_validator.citation_integrity(bundle, refs),
                    "evidence_sufficiency": official_validator.evidence_sufficiency(bundle, ref, pred.status, refs),
                    "status_evidence_validity": official_validator.status_evidence_validity(bundle, ref, pred.status, refs),
                    "identifier_evidence_validity": official_validator.identifier_evidence_validity(
                        bundle, ref, pred.status, pred.final_id, pred.merge_target_id, refs),
                    "full_evidence_validity": official_validator.full_evidence_validity(
                        bundle, ref, pred.status, pred.final_id, pred.merge_target_id, refs),
                }
            path.write_text(json.dumps({
                "scenario_id": cell["scenario_id"], "level": cell["level"], "condition": "P2",
                "sample": i, "reference": cell["reference_status"], "fingerprint": cell["fingerprint"],
                "request_params": resp.request_params, "prediction": rec.model_dump(mode="json"),
                "evidence_refs": refs, "chain_validity": validity,
                "input_tokens": resp.input_tokens, "output_tokens": resp.output_tokens,
                "text": resp.text, "raw": resp.raw,
            }, indent=2, default=str))
    print(f"benchmark run complete -> {out}")
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="benchmark",
                                     description="Official v0.2 benchmark (single prompt P2, validator v2)")
    sub = parser.add_subparsers(dest="command", required=True)
    pb = sub.add_parser("build", help="offline build + verify (zero API calls)")
    pb.add_argument("--config", default=None)
    pb.set_defaults(func=cmd_build)
    pr = sub.add_parser("run", help="live benchmark run (needs ANTHROPIC_API_KEY)")
    pr.add_argument("--config", default=None)
    pr.set_defaults(func=cmd_run)
    args = parser.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
