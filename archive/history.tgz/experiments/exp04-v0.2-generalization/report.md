# Experiment 04 — Benchmark v0.2 generalization (offline build & validation)

**Question:** do the evidence-grounding improvements from Experiment 03 (frozen P1/P2)
**generalize** to 15 previously-unseen, independent scenarios — reducing unsupported positives
without inducing over-abstention?

**This report covers the OFFLINE build only.** No API calls have been made. The live run is
gated on your approval (see the cost estimate below). Design: [`design/benchmark-v0.2-design.md`](../../design/benchmark-v0.2-design.md).

## Approved decisions implemented

1. Answer-neutral **canonical-vs-final id clause** added to the shared base template, applied
   identically to P0/P1/P2 (`base_v2`).
2. **Structured `evidence_refs`** with deterministic validation, versioned as a new P2
   output-contract (`structured evidence_refs v2`). The **P1 grounding block is byte-identical
   to `frozen_v1`** (freeze-checked, sha256 `99e2a677…`); the frozen free-text P2 contract is
   preserved untouched in `prompts/frozen_v1/`.
3. **k = 3** general tasks, **k = 5** for the four calibration probes (S09–S12).
4. All **15** scenarios kept.
5. Results under `experiments/exp04-v0.2-generalization/`.

## Corrections applied (per your three notes)

- **Temperature omitted.** The provider already omits `temperature` for `claude-sonnet-5`; the
  v0.2 fingerprint/provenance carries **no temperature key**, matching Experiment 03.
- **Structured schema is versioned, not a frozen-P2 edit.** `frozen_v1` hashes are untouched;
  the new structured contract is recorded separately in `prompt_manifest.json`.
- **S08 rechecked against the WRONG_MERGE rule — scenario fixed, solver untouched.** S08 now
  establishes WRONG_MERGE from the **observable same-namespace contradiction between two members**
  of canonical `C8` (US-MA `7712300` vs `7798801`), which is genuinely observable; the absorbing
  canonical is **not emitted to `final_dataset`**, so `merge_target_id` is correctly **null**
  (`merge_target_observable=False`). The reference-generation gate confirms
  `solve(S08:full) = WRONG_MERGE / target null`. No solver change or special-casing.

## Offline gate results — all passing

| Gate | What it checks | Result |
|---|---|---|
| 1. Reference-generation | `solve()` == authored expected label/ids for every (scenario, level) | **34/34 cells match** |
| 2. Counterfactual hash | S11 vs S11B observable minimal bundles byte-identical; references equal | **identical** (sha `a1d1a032…`, both UND) |
| 3. Validation | no ground-truth leakage; determinability monotone full→partial→minimal; ≥6 transition scenarios | **pass** (6 transition scenarios) |
| 4. Baselines | name-similarity fires a *wrong* positive on the calibration probes; strong-id solves the positive controls | **pass** (S04, S09, S10, S11, S12 baseline-wrong as designed) |
| 5. Freeze check | P1 grounding block byte-identical to `frozen_v1` | **pass** |
| 6. Prompt render + matrix | 99 prompts rendered and hashed; task matrix built | **pass** (combined sha `843841ef…`) |
| Validator unit tests | structured `evidence_refs` 3-way validity on valid + adversarial fixtures | **7/7 pass** |
| POC regression | existing `pytest` suite after the observability refactor | **50/50 pass** |

Reproduce: `gates_core.py`, `gates_build.py`, `test_validators.py` in this directory.

## Task matrix

- **15 primary scenarios**, **33 observable task-conditions** (scenario × level), **99 cells**
  (× 3 conditions). S11B (counterfactual twin) adds **0** API cells — its prompt is byte-identical
  to S11; it is scored under both hidden-truth framings.
- Group A (positive controls) S01, S02, S14 — 3 levels. Group B (transitions) S03–S07, S15 —
  3 levels. Group C (merge/id) S08, S13 — full only. Group D (calibration) S09–S12 — minimal, k=5.
- Reference-status distribution across cells (per condition, 33 cells): PRESENT ×9 lvls,
  INGESTION_LOSS ×2, EXTRACTION_LOSS ×2, FILTERED_OUT ×3, WRONG_MERGE ×2 (one target-null),
  UNDETERMINABLE ×15.

Full matrix with per-cell reference answers, prompt files, and fingerprints:
[`task_matrix.json`](task_matrix.json). Prompt hashes: [`prompt_manifest.json`](prompt_manifest.json).

## Estimated API cost (for approval)

| | |
|---|---|
| Model | `claude-sonnet-5`, `max_tokens=8192`, temperature omitted |
| Total calls | **321** (107 per condition) |
| k | 3 general, 5 calibration (S09–S12) |
| **Estimated cost** | **≈ $2.6** (band **$2.5–4**; dense JSON tokenizes slightly above the chars/4 estimate) |

Estimate method: input tokens ≈ rendered-prompt chars / 4 (prompts are 5.6–7.3k chars ≈
1.4–1.8k input tokens); output tokens from Exp-03 per-condition averages (P0 665, P1 397, P2 425);
sonnet-5 pricing $2/M in, $10/M out. See [`cost_estimate.json`](cost_estimate.json).

## Status: STOP for approval

The offline gates are green and the matrix + cost are fixed. **No live run will start without
your approval.** On approval, the live run will: preflight the model id, execute the 321 calls
resumably (fingerprint = model + max_tokens + prompt_sha256, no temperature), preserve every raw
response, then score status/full accuracy, unsupported-positive & correct-abstention rates
(macro-averaged across scenarios), paired evidence-transition accuracy per scenario, and P2's
three-way evidence-chain validity — with the pre-registered generalization verdict rule fixed in
advance. Prompts will not be tuned after seeing any evaluation output.
