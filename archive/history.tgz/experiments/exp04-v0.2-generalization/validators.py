"""Structured evidence_refs — schema + deterministic three-way validity (v0.2, Requirement 5).

A v0.2 P2 answer cites evidence as a JSON array of structured objects:

    {"artifact": "<name>", "match": {"<field>": "<value>", ...}}

Allowed artifacts: source_records, final_dataset, ingestion_manifest, extraction_log,
normalized_records, resolution_map, merge_decision_log, filter_log. `source_records` and
`final_dataset` support a synthetic "strong_id" field (a namespaced key such as
"registry:US-DE/4830012" or "duns/11-2200-345").

Three validities, computed only for POSITIVE answers (UNDETERMINABLE cites nothing):

  status_evidence_validity      — the cited rows exist, are non-MISSING, are not a bare
                                  name match, and include the artifact(s) that establish the
                                  claimed STATUS; and the status matches the reference.
  identifier_evidence_validity  — the reported final_id / merge_target_id is a PUBLIC final id
                                  (never an internal canonical id), is itself cited, and matches
                                  the reference (or is correctly null when the target is not
                                  observable / no identifier applies).
  full_evidence_validity        — status ∧ identifier.

This is deterministic and LLM-free: it re-checks the model's citations against the observable
bundle and the reference solver's answer.
"""
from __future__ import annotations

from poc.models import ArtifactState, Label, ObservableBundle, ReferenceAnswer

ALLOWED_ARTIFACTS = {"source_records", "final_dataset", "ingestion_manifest", "extraction_log",
                     "normalized_records", "resolution_map", "merge_decision_log", "filter_log"}

# Minimal establishing-artifact requirement per status (the model must cite at least one option).
# Each entry is a list of acceptable "citation shapes" (see _cites_shape).
_STATUS_REQUIRES = {
    Label.PRESENT_UNDER_OTHER_ID: "present",
    Label.INGESTION_LOSS: "ingestion",
    Label.EXTRACTION_LOSS: "extraction",
    Label.FILTERED_OUT: "filtered",
    Label.WRONG_MERGE: "wrong_merge",
}


def _source_strong_keys(src: dict) -> set[str]:
    t = src.get("source_type")
    if t == "registry":
        return {f"registry:{src['jurisdiction']}/{src['registration_number']}"}
    if t == "directory" and src.get("duns"):
        return {f"duns/{src['duns']}"}
    return set()


def _final_strong_keys(row: dict) -> set[str]:
    return {f"{s['namespace']}/{s['value']}" for s in row.get("strong_ids", [])}


def _rows_for(bundle: ObservableBundle, artifact: str) -> list[dict] | None:
    """Return the observable rows for a cited artifact, or None if it is not citable
    (unknown name, or a MISSING intermediate artifact)."""
    if artifact == "source_records":
        return bundle.sources
    if artifact == "final_dataset":
        return bundle.final_dataset
    if artifact not in ALLOWED_ARTIFACTS:
        return None
    art = bundle.artifact(artifact)
    if art.state is ArtifactState.MISSING:
        return None
    return art.rows


def _row_matches(bundle: ObservableBundle, artifact: str, row: dict, match: dict) -> bool:
    for field, value in match.items():
        if field == "strong_id":
            keys = _source_strong_keys(row) if artifact == "source_records" else (
                _final_strong_keys(row) if artifact == "final_dataset" else set())
            if value not in keys:
                return False
        else:
            if str(row.get(field)) != str(value):
                return False
    return True


def _ref_grounded(bundle: ObservableBundle, ref: dict) -> bool:
    """A single structured citation is grounded iff its artifact is citable and some row matches."""
    if not isinstance(ref, dict):
        return False
    artifact = ref.get("artifact")
    match = ref.get("match") or {}
    rows = _rows_for(bundle, artifact)
    if rows is None or not isinstance(match, dict) or not match:
        return False
    return any(_row_matches(bundle, artifact, r, match) for r in rows)


def _cited_artifacts(bundle: ObservableBundle, refs: list[dict]) -> set[str]:
    return {r.get("artifact") for r in refs if _ref_grounded(bundle, r)}


def _present_by_strong_id(bundle: ObservableBundle, refs: list[dict]) -> bool:
    """True iff the citations show a strong-id share between a source and a final row."""
    src_ok = any(_ref_grounded(bundle, r) and r.get("artifact") == "source_records"
                 and "strong_id" in (r.get("match") or {}) for r in refs)
    fin_ok = any(_ref_grounded(bundle, r) and r.get("artifact") == "final_dataset"
                 and "strong_id" in (r.get("match") or {}) for r in refs)
    return src_ok and fin_ok


def _cites_shape(bundle: ObservableBundle, refs: list[dict], shape: str) -> bool:
    cited = _cited_artifacts(bundle, refs)
    if shape == "present":
        # strong-id share, OR a resolution_map + final_dataset chain (never name-only).
        if _present_by_strong_id(bundle, refs):
            return True
        return {"resolution_map", "final_dataset"} <= cited
    if shape == "ingestion":
        return "ingestion_manifest" in cited
    if shape == "extraction":
        return "extraction_log" in cited
    if shape == "filtered":
        return "filter_log" in cited
    if shape == "wrong_merge":
        return bool({"merge_decision_log", "resolution_map"} & cited)
    return False


def status_evidence_validity(bundle: ObservableBundle, reference: ReferenceAnswer,
                             claimed_status: Label, refs: list[dict]) -> bool:
    if claimed_status is Label.UNDETERMINABLE:
        return True  # abstention: nothing to establish
    if not refs or not all(_ref_grounded(bundle, r) for r in refs):
        return False  # ungrounded / MISSING-artifact / no-match citation
    if claimed_status is not reference.status:
        return False  # the cited evidence cannot establish a status the evidence does not support
    shape = _STATUS_REQUIRES.get(claimed_status)
    return bool(shape and _cites_shape(bundle, refs, shape))


def _cites_final_id(bundle: ObservableBundle, refs: list[dict], final_id: str) -> bool:
    return any(_ref_grounded(bundle, r) and r.get("artifact") == "final_dataset"
               and str((r.get("match") or {}).get("final_id")) == str(final_id) for r in refs)


def identifier_evidence_validity(bundle: ObservableBundle, reference: ReferenceAnswer,
                                 claimed_status: Label, claimed_final_id: str | None,
                                 claimed_merge_target_id: str | None, refs: list[dict]) -> bool:
    final_ids = {r["final_id"] for r in bundle.final_dataset}
    canon_ids = {r["canonical_id"] for r in bundle.final_dataset}

    def is_public(x: str | None) -> bool:
        # a public final id is in final_ids; an internal canonical id is in canon_ids (but not final_ids)
        return x in final_ids and not (x in canon_ids and x not in final_ids)

    if reference.status is Label.PRESENT_UNDER_OTHER_ID:
        if not is_public(claimed_final_id) or claimed_final_id != reference.final_id:
            return False
        if claimed_merge_target_id is not None:
            return False
        return _cites_final_id(bundle, refs, claimed_final_id)

    if reference.status is Label.WRONG_MERGE:
        if claimed_final_id is not None:
            return False
        if reference.merge_target_observable:
            if not is_public(claimed_merge_target_id) or claimed_merge_target_id != reference.merge_target_id:
                return False
            return _cites_final_id(bundle, refs, claimed_merge_target_id)
        # target not observable -> must be null
        return claimed_merge_target_id is None

    # INGESTION_LOSS / EXTRACTION_LOSS / FILTERED_OUT / UNDETERMINABLE -> no identifier expected
    return claimed_final_id is None and claimed_merge_target_id is None


def full_evidence_validity(bundle: ObservableBundle, reference: ReferenceAnswer,
                           claimed_status: Label, claimed_final_id: str | None,
                           claimed_merge_target_id: str | None, refs: list[dict]) -> bool:
    return (status_evidence_validity(bundle, reference, claimed_status, refs)
            and identifier_evidence_validity(bundle, reference, claimed_status,
                                             claimed_final_id, claimed_merge_target_id, refs))
