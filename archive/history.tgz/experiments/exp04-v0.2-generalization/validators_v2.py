"""Corrected evidence_refs validator (v2) — audit follow-up to Experiment 04.

Motivation: the v1 status validator produced false negatives on CORRECT P2 answers. The audit
(validator_audit.md) classified all 12 v1 failures individually. v2 fixes only the justified
issues and **keeps evidence sufficiency and citation integrity as separate axes**:

  * citation_integrity   — every cited ref is grounded: it names a REAL, observable row (or a
                           genuine completeness guarantee), never a hallucinated or MISSING one.
  * evidence_sufficiency — the GROUNDED refs actually establish the claimed status.

`status_evidence_validity = integrity AND sufficiency AND status==reference`.

Corrections vs v1 (each justified by an audited false negative), NOT relaxations of rigor:
  (A) A source strong-id citation may use the record's REAL field (`registration_number` for
      registry, `duns` for directory) — not only the synthetic `strong_id` key. The share is
      re-derived from the actual matched rows, so it cannot be faked.
  (B) List-valued fields (`strong_ids`) match by MEMBERSHIP, so a real normalized_records /
      final_dataset row is grounded when cited.
  (C) Absence-based labels (INGESTION_LOSS) may cite a completeness guarantee via
      `{"guaranteed_complete_for": "<batch>"}`, grounded iff the artifact is COMPLETE for it —
      there is no row to cite for an absent record.

What v2 does NOT do (verified by the adversarial tests): it still rejects name-only citations,
MISSING-artifact citations, canonical-id-as-final-id, and citations that omit the identity link
(the 2 genuine weak citations stay invalid).
"""
from __future__ import annotations

from poc.models import ArtifactState, Label, ObservableBundle, ReferenceAnswer

from validators import (  # reuse the primitives that need no change
    ALLOWED_ARTIFACTS,
    _final_strong_keys,
    _source_strong_keys,
    identifier_evidence_validity,  # id logic already correct (100% in the run); reused unchanged
)

_STATUS_SHAPE = {
    Label.PRESENT_UNDER_OTHER_ID: "present",
    Label.INGESTION_LOSS: "ingestion",
    Label.EXTRACTION_LOSS: "extraction",
    Label.FILTERED_OUT: "filtered",
    Label.WRONG_MERGE: "wrong_merge",
}


def _rows_for(bundle: ObservableBundle, artifact: str):
    if artifact == "source_records":
        return bundle.sources
    if artifact == "final_dataset":
        return bundle.final_dataset
    if artifact not in ALLOWED_ARTIFACTS:
        return None
    art = bundle.artifact(artifact)
    if art.state is ArtifactState.MISSING:
        return None
    return art.rows


def _value_matches(row_val, want) -> bool:
    # (B) list-valued fields: accept membership OR whole-list equality (v1 matched the whole list
    # by string equality; v2 additionally allows citing a single member, e.g. one strong id).
    if isinstance(row_val, list):
        members = [str(x) for x in row_val]
        if isinstance(want, list):
            return [str(x) for x in want] == members
        return str(want) in members or str(want) == str(row_val)
    return str(row_val) == str(want)


def _field_matches(artifact: str, row: dict, field: str, want) -> bool:
    # synthetic "strong_id" field: resolve against the row's derived strong-id keys
    if field == "strong_id":
        if artifact == "source_records":
            return want in _source_strong_keys(row)
        if artifact == "final_dataset":
            return want in _final_strong_keys(row)
        return False
    return _value_matches(row.get(field), want)


def _matched_rows(bundle: ObservableBundle, ref: dict):
    """Rows matched by a structured ref, plus a flag for a completeness-guarantee citation."""
    if not isinstance(ref, dict):
        return [], False
    artifact, match = ref.get("artifact"), ref.get("match") or {}
    if not isinstance(match, dict) or not match:
        return [], False
    # (C) completeness-guarantee citation (for absence-based labels)
    if "guaranteed_complete_for" in match:
        art = bundle.artifact(artifact) if artifact in ALLOWED_ARTIFACTS else None
        scope = match["guaranteed_complete_for"]
        if art is not None and art.state is ArtifactState.COMPLETE and scope in art.complete_scopes:
            return [], True
        return [], False
    rows = _rows_for(bundle, artifact)
    if rows is None:
        return [], False
    hits = [r for r in rows if all(_field_matches(artifact, r, f, v) for f, v in match.items())]
    return hits, False


def _grounded(bundle: ObservableBundle, ref: dict) -> bool:
    rows, completeness = _matched_rows(bundle, ref)
    return bool(rows) or completeness


def citation_integrity(bundle: ObservableBundle, refs: list[dict]) -> bool:
    """Every cited ref names a real observable row or a genuine completeness guarantee."""
    return bool(refs) and all(_grounded(bundle, r) for r in refs)


def _cited_artifacts(bundle: ObservableBundle, refs: list[dict]) -> set[str]:
    return {r.get("artifact") for r in refs if _grounded(bundle, r)}


def _present_sufficient(bundle: ObservableBundle, refs: list[dict]) -> bool:
    # (A) strong-id share explicitly cited on both sides, re-derived from the matched rows.
    src_keys, fin_keys = set(), set()
    for r in refs:
        if not _grounded(bundle, r):
            continue
        match = r.get("match") or {}
        rows, _ = _matched_rows(bundle, r)
        if r.get("artifact") == "source_records" and ({"strong_id", "registration_number", "duns"} & set(match)):
            for row in rows:
                src_keys |= _source_strong_keys(row)
        if r.get("artifact") == "final_dataset" and ({"strong_id", "strong_ids"} & set(match)):
            for row in rows:
                fin_keys |= _final_strong_keys(row)
    if src_keys & fin_keys:
        return True
    # OR an explicit resolution_map -> final_dataset lineage chain
    return {"resolution_map", "final_dataset"} <= _cited_artifacts(bundle, refs)


def evidence_sufficiency(bundle: ObservableBundle, reference: ReferenceAnswer,
                         claimed_status: Label, refs: list[dict]) -> bool:
    if claimed_status is Label.UNDETERMINABLE:
        return True
    if claimed_status is not reference.status:
        return False
    shape = _STATUS_SHAPE.get(claimed_status)
    cited = _cited_artifacts(bundle, refs)
    if shape == "present":
        return _present_sufficient(bundle, refs)
    if shape == "ingestion":
        return "ingestion_manifest" in cited
    if shape == "extraction":
        return "extraction_log" in cited
    if shape == "filtered":
        return "filter_log" in cited
    if shape == "wrong_merge":
        return bool({"merge_decision_log", "resolution_map"} & cited)
    return False


def status_evidence_validity(bundle: ObservableBundle, reference: ReferenceAnswer,
                             claimed_status: Label, refs: list[dict]) -> bool:
    if claimed_status is Label.UNDETERMINABLE:
        return True
    return (citation_integrity(bundle, refs)
            and evidence_sufficiency(bundle, reference, claimed_status, refs))


def full_evidence_validity(bundle: ObservableBundle, reference: ReferenceAnswer,
                           claimed_status: Label, claimed_final_id: str | None,
                           claimed_merge_target_id: str | None, refs: list[dict]) -> bool:
    return (status_evidence_validity(bundle, reference, claimed_status, refs)
            and identifier_evidence_validity(bundle, reference, claimed_status,
                                             claimed_final_id, claimed_merge_target_id, refs))
