# Experiment 04 — Benchmark v0.2 generalization: comparative analysis

**Question:** do the Experiment-03 evidence-grounding gains (frozen P1/P2) **generalize** to 15
previously-unseen, independent scenarios — cutting unsupported positives without over-abstention?

**Answer: yes, for both P1 and P2**, on unseen scenarios, under the pre-registered verdict rule.
This was a pre-registered run: prompts, scenarios, reference labels, and evaluation rules were
frozen before the run and **not modified after** observing any output.

**Run:** 321 live calls, `claude-sonnet-5`, `max_tokens=8192`, temperature omitted (model rejects
it — matches Exp 03). **0 failures. 0 malformed. Real cost $3.05** (guardrail $5). Fully resumable;
every raw response, rendered prompt, request config, token usage, prediction, and P2 validity flag
is preserved under [`samples/`](samples/). Machine summary: [`analysis_summary.json`](analysis_summary.json).

## Headline metrics

Scenario-level (macro) is the **primary** generalization metric — the three observability variants
of one probe are correlated, so we average within scenario first, then across scenarios. Task-level
(micro) pools all samples.

### Scenario-level (macro; primary)

| Metric | P0 | P1 | P2 |
|---|---|---|---|
| Status accuracy | 0.895 | 0.985 | **1.000** |
| Full-answer accuracy | 0.895 | 0.985 | **1.000** |
| **Unsupported-positive rate** (ref=UND) | **0.247** | **0.033** | **0.000** |
| Correct-abstention rate | 0.753 | 0.967 | **1.000** |
| Correct-positive rate (full, determinable) | 1.000 | 1.000 | 1.000 |

### Task-level (micro)

| Metric | P0 | P1 | P2 |
|---|---|---|---|
| Status accuracy | 0.897 | 0.981 | **1.000** |
| Full-answer accuracy | 0.897 | 0.981 | **1.000** |
| Unsupported-positive rate | 0.250 | 0.045 | **0.000** |
| Correct-abstention rate | 0.750 | 0.955 | **1.000** |
| Correct-positive rate (full) | 1.000 | 1.000 | 1.000 |
| Malformed | 0 | 0 | 0 |
| Cost | $1.18 | $0.89 | $0.98 |

**Pre-registered verdict (applied mechanically, unmodified):** for both P1 and P2 —
(i) unsupported-positive macro **decreases** (0.247 → 0.033 → 0.000), (ii) correct-positive macro
**does not drop** (1.000 throughout), (iii) status-accuracy macro **does not drop** (0.895 → 0.985 →
1.000). **Both conditions PASS. The grounding effect generalizes.**

## Correct-positive rate held at 1.000 everywhere — no over-abstention

The central risk of a grounding intervention is that it makes the model abstain on cases it should
commit to. It did not: on the 23 observable determinable task-conditions (positive controls +
determinable levels of the transitions), **P1 and P2 kept full correct-positive rate at 1.000**,
identical to P0. In particular S14 (present via strong id at *every* level, including minimal) stayed
`PRESENT` under all conditions — the "minimal ⇒ abstain" shortcut did not appear.

## Paired evidence-transition accuracy (per scenario, macro)

For the six transition scenarios, a sample is transition-correct iff it is correct at **both**
bracketing levels — i.e. it commits when the evidence is present **and** abstains when it is removed.

| | P0 | P1 | P2 |
|---|---|---|---|
| Macro transition accuracy | 0.611 | 0.889 | **1.000** |
| S03 (present-via-map → UND) | 0.00 | 1.00 | 1.00 |
| S04 (ingestion loss → UND) | 1.00 | 1.00 | 1.00 |
| S05 (extraction loss → UND) | 1.00 | 1.00 | 1.00 |
| S06 (filtered → UND) | 1.00 | 1.00 | 1.00 |
| S07 (wrong-merge → UND) | 0.67 | 1.00 | 1.00 |
| S15 (filtered, link dropped at partial → UND) | 0.00 | 0.33 | 1.00 |

The whole benchmark exists to measure this "same record, different defensible answer as evidence is
removed" behavior. P0 fails it on the hardest cases (S03, S15); grounding fixes it, and P2 is perfect.

## Negative results & the hardest scenario (S15)

Reported in full, including regressions:

- **P0 over-claimed 11 times** (all on reference-UND tasks): S12:minimal ×4 (ambiguous multi-match),
  S03:minimal ×3 (map gone), S15:partial ×3 (filtered, link dropped), S07:partial ×1 (merge, link
  dropped). These are exactly the calibration traps the benchmark was built to expose.
- **P1 over-claimed 2 times**, both on **S15:partial** — the single hardest cell. There the filter
  log is still COMPLETE (showing the canonical was dropped) but the probe's resolution row is gone,
  so the probe cannot be observably tied to that canonical → the answer is UNDETERMINABLE. P1 twice
  still concluded FILTERED_OUT. P2 got it right 3/3.
- **No regressions of the over-abstention kind:** neither P1 nor P2 ever turned a determinable task
  into a wrong abstention or a wrong label. The only movement was UND-trap → correct abstention.

## P2 evidence-chain validity (the three metrics)

Scored over the **63 positive P2 answers** (abstentions cite nothing):

| Validity | Rate | Count |
|---|---|---|
| `status_evidence_validity` | 0.810 | 51 / 63 |
| **`identifier_evidence_validity`** | **1.000** | **63 / 63** |
| `full_evidence_validity` | 0.810 | 51 / 63 |

- **Identifier validity is perfect (1.000).** Every reported `final_id` / `merge_target_id` was a
  **public `ENT-###`** (never an internal canonical `C##`) and was cited. **The canonical-vs-final id
  clause worked** — the Exp-03 id-granularity slip did not recur anywhere, including the id-granularity
  stress scenario S13 and the target-null merge S08.
- **The 0.810 status-validity is a validator-strictness artifact, not a wrong answer.** All 12
  "invalid" cases are **fully correct answers** whose citations my structured validator scored too
  harshly. Two causes: (a) the model cited a source record's strong id by its **real field name**
  (`registration_number` / `strong_ids`) instead of the validator's synthetic `strong_id` key, so the
  strong-id share wasn't credited; (b) the model added an **extra** grounded-looking ref (e.g.
  `normalized_records` with `strong_ids` as a list) that didn't match my strict row-matcher, and the
  validator requires *every* cited ref to ground. All 12 are `PRESENT`/`WRONG_MERGE` answers that are
  correct and whose identifier citation is valid. **Per the pre-registration, I did not change the
  validator after seeing this.** Recommended for a *future* version (not applied here): accept the real
  source field names as strong-id citations and don't fail a citation set on a single extra grounded
  ref.

## Failure-mode breakdown

| Failure mode | P0 | P1 | P2 |
|---|---|---|---|
| Unsupported positive (ref=UND → positive) | 11 | 2 | 0 |
| Over-abstention (determinable → UND) | 0 | 0 | 0 |
| Wrong label (determinable → other positive) | 0 | 0 | 0 |
| Wrong identifier (status right, id wrong) | 0 | 0 | 0 |
| Malformed | 0 | 0 | 0 |

Every P0 and P1 error is the **same** failure mode — an unsupported positive on an
insufficient-evidence task — which is precisely the calibration behavior Experiments 01–03 isolated.
The grounding instructions remove it, and add auditability (structured citations) at ~no cost:
output tokens actually fell from 73.9k (P0) to 38.5k/40.3k (P1/P2).

## Interpretation

1. **The Exp-03 result generalizes.** On 15 unseen, independent scenarios the frozen grounding
   blocks cut the macro unsupported-positive rate 0.247 → 0.033 (P1) → 0.000 (P2) with **zero**
   over-abstention and no loss of correct-positive accuracy. The verdict rule, fixed in advance,
   passes for both conditions.
2. **P2 ≥ P1 here.** P2 reached perfect status/full accuracy and transition accuracy and fixed the
   two residual P1 failures on the hardest cell (S15:partial). The mandatory structured citation
   appears to force the "can I actually cite a link?" check that S15:partial specifically defeats.
3. **The id clause solved the id-granularity problem.** Identifier-evidence validity is 100%.
4. **One measurement caveat, honestly flagged:** the structured-citation *status*-validator is
   conservative and under-counts correct citations that use real field names; the underlying P2
   answers and identifiers are sound. This is a validator refinement for a future run, not a result
   about the model.

## What is NOT being done next

Per instruction, no prompt optimization and no follow-on experiment are being started automatically.
The natural (un-started) next steps, for your decision only: fold the id clause + grounding block into
the default scored prompt; relax the structured-citation *status* validator to accept real field names
(re-scoring the preserved P2 responses offline, zero new API calls); and add more S15-style
"link-removed" hard cells to stress calibration further.
