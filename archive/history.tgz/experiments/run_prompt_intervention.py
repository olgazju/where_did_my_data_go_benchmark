"""Experiment 03 — controlled prompt-intervention comparison (P0 / P1 / P2).

Research question: can explicit evidence-grounding instructions reduce unsupported positive
conclusions WITHOUT increasing incorrect abstentions?

Fixed across conditions: model, observable artifacts, the 18 paired tasks, request params,
and the reference-solver answers. Only the prompt text changes.

  P0 — baseline (byte-identical to Pilot 01; loaded from the preserved run).
  P1 — P0 + explicit evidence-sufficiency / abstention rules (name similarity never
       establishes identity).
  P2 — P1 + mandatory `evidence_refs` for positive conclusions, with deterministic
       validation of whether the cited artifacts actually establish the claimed outcome.

This is a controlled comparison, not an optimization loop: the P1/P2 wording is fixed and
NOT tuned against the 18 tasks. Every prompt version and raw response is preserved
separately. Pilot 01 and Experiments 01–02 are untouched.

Usage:
    ANTHROPIC_API_KEY=... uv run --locked python experiments/run_prompt_intervention.py
"""

from __future__ import annotations

import hashlib
import json
from collections import Counter
from pathlib import Path

from poc.evaluator import evaluate_one, parse_prediction
from poc.models import ArtifactState, Label, Observability, ReferenceAnswer
from poc.observability import build_bundle
from poc.provider.anthropic import AnthropicProvider
from poc.provider.base import LLMRequest
from poc.simulator import simulate
from poc.solver import solve

REPO = Path(__file__).resolve().parents[1]
PILOT = REPO / "runs" / "sample" / "pilot-01"
OUT = REPO / "experiments" / "exp03-prompt-intervention"
MODEL = "claude-sonnet-5"
MAX_TOKENS = 8192
TEMPERATURE = 0.0

LEVEL = {"full": Observability.FULL, "partial": Observability.PARTIAL, "minimal": Observability.MINIMAL}

P1_RULES = """\
# Evidence-grounding rules
- Base your status ONLY on what the available artifacts POSITIVELY ESTABLISH. Do not guess.
- Name similarity ALONE never establishes identity. To answer PRESENT_UNDER_OTHER_ID you need
  either (a) a strong identifier shared between the source record and a final record, or (b) an
  explicit lineage link (resolution map and/or merge-decision log) tying the record to a final entity.
- If the available evidence is consistent with more than one outcome — e.g. the record could match
  two different final entities, or could equally have been lost, filtered, or merged — you MUST
  answer UNDETERMINABLE.
- Absence of a record is evidence ONLY inside an artifact that is COMPLETE for the relevant scope;
  in a PARTIAL or MISSING artifact, absence proves nothing.
- Prefer UNDETERMINABLE over an unsupported positive claim.

"""

P2_CITATIONS = """\
# Evidence citations (required)
For any status other than UNDETERMINABLE you MUST populate "evidence_refs" with the specific
artifact rows/fields that establish your conclusion, drawn ONLY from the artifacts shown above
(e.g. "resolution_map: SRC-104 -> C10", "final_dataset: ENT-501 shares strong_id duns/11-2200-345
with source", "ingestion_manifest COMPLETE for B1; SRC-101 absent"). Do NOT cite name similarity.
If you cannot cite establishing artifacts, answer UNDETERMINABLE with an empty evidence_refs list.

"""

_MERGE_LINE = ('  "merge_target_id": "<the id it was wrongly merged into if status is WRONG_MERGE '
               'and that id is observable, else null>"\n}')
_MERGE_LINE_P2 = ('  "merge_target_id": "<the id it was wrongly merged into if status is WRONG_MERGE '
                  'and that id is observable, else null>",\n'
                  '  "evidence_refs": ["<artifact rows/fields that establish the status; use [] for UNDETERMINABLE>"]\n}')

ARTIFACT_VOCAB = ["ingestion_manifest", "extraction_log", "normalized_records",
                  "resolution_map", "merge_decision_log", "filter_log"]


def build_prompts(p0: str) -> dict[str, str]:
    p1 = p0.replace("# Task", P1_RULES + "# Task", 1)
    p2 = p1.replace("# Task", P2_CITATIONS + "# Task", 1).replace(_MERGE_LINE, _MERGE_LINE_P2, 1)
    assert "evidence_refs" in p2, "P2 schema patch failed"
    return {"P0": p0, "P1": p1, "P2": p2}


def _fp(prompt: str) -> dict:
    return {"requested_model": MODEL, "provider": "anthropic", "max_tokens": MAX_TOKENS,
            "temperature": TEMPERATURE, "prompt_sha256": hashlib.sha256(prompt.encode()).hexdigest()}


def _evidence_refs(text: str):
    if "{" not in text:
        return None
    try:
        return json.loads(text[text.find("{"): text.rfind("}") + 1]).get("evidence_refs")
    except Exception:  # noqa: BLE001
        return None


def chain_validity(bundle, source_id: str, pred_status: Label, refs) -> bool | None:
    """P2 only: does the cited evidence actually establish a positive claim? None if abstained."""
    if pred_status is Label.UNDETERMINABLE:
        return None
    ref_status = solve(bundle, source_id).status
    reflist = refs or []
    text = " ".join(str(r).lower() for r in reflist)
    grounded = bool(reflist)
    if any(k in text for k in ("name similar", "similar name", "name match", "name-similarity", "similarity")):
        grounded = False
    for aname in ARTIFACT_VOCAB:
        if aname in text and bundle.artifact(aname).state is ArtifactState.MISSING:
            grounded = False
    sufficient = pred_status is ref_status  # the evidence genuinely establishes the claim
    return bool(grounded and sufficient)


def run() -> None:
    tasks = json.loads((PILOT / "tasks" / "tasks.json").read_text())  # P0 == Pilot 01 prompt
    refs = {k: ReferenceAnswer.model_validate(v)
            for k, v in json.loads((PILOT / "tasks" / "references.json").read_text()).items()}
    sim = simulate()
    bundles = {lvl: build_bundle(sim, obs) for lvl, obs in LEVEL.items()}

    provider = AnthropicProvider(model=MODEL)
    (OUT / "prompts").mkdir(parents=True, exist_ok=True)

    # save every prompt version
    for t in tasks:
        for cond, text in build_prompts(t["prompt"]).items():
            d = OUT / "prompts" / cond
            d.mkdir(parents=True, exist_ok=True)
            (d / f"{t['task_id']}.txt").write_text(text)

    need = any(not (OUT / "samples" / c / f"{t['task_id']}.json").exists()
               for t in tasks for c in ("P0", "P1", "P2"))
    if need:
        provider.preflight()

    for cond in ("P0", "P1", "P2"):
        (OUT / "samples" / cond).mkdir(parents=True, exist_ok=True)
        for t in tasks:
            tid = t["task_id"]
            path = OUT / "samples" / cond / f"{tid}.json"
            if path.exists():
                continue
            prompt = build_prompts(t["prompt"])[cond]
            resp = provider.complete(LLMRequest(model=MODEL, max_tokens=MAX_TOKENS,
                                                temperature=TEMPERATURE, prompt=prompt))
            rec = evaluate_one(tid, refs[tid], resp.text)
            ev = _evidence_refs(resp.text) if cond == "P2" else None
            valid = None
            if cond == "P2" and not rec.malformed:
                pred = parse_prediction(resp.text).prediction
                if pred is not None:
                    valid = chain_validity(bundles[t["level"]], t["source_id"], pred.status, ev)
            path.write_text(json.dumps({
                "task_id": tid, "condition": cond, "source_id": t["source_id"], "level": t["level"],
                "reference_status": refs[tid].status.value,
                "request_params": resp.request_params, "fingerprint": _fp(prompt),
                "text": resp.text, "input_tokens": resp.input_tokens, "output_tokens": resp.output_tokens,
                "prediction": rec.model_dump(mode="json"),
                "evidence_refs": ev, "chain_valid": valid, "raw": resp.raw,
            }, indent=2, default=str))
            print(f"  {cond} {tid:<16} ref={refs[tid].status.value:<22} pred={rec.predicted_status} "
                  f"full={rec.full_correct}" + (f" chain_valid={valid}" if cond == "P2" else ""))

    summarize(tasks, refs)


def _load(cond: str) -> dict[str, dict]:
    return {p.stem: json.loads(p.read_text()) for p in (OUT / "samples" / cond).glob("*.json")}


def summarize(tasks, refs) -> None:
    undet_ids = [t["task_id"] for t in tasks if refs[t["task_id"]].status is Label.UNDETERMINABLE]
    det_ids = [t["task_id"] for t in tasks if refs[t["task_id"]].status is not Label.UNDETERMINABLE]
    conds = {c: _load(c) for c in ("P0", "P1", "P2")}

    per_cond = {}
    for c, data in conds.items():
        recs = [data[t["task_id"]] for t in tasks]
        n = len(recs)
        status_correct = sum(r["prediction"]["status_correct"] for r in recs)
        full_correct = sum(r["prediction"]["full_correct"] for r in recs)
        malformed = sum(r["prediction"]["malformed"] for r in recs)
        unsup_pos = sum(1 for tid in undet_ids
                        if not data[tid]["prediction"]["malformed"]
                        and data[tid]["prediction"]["predicted_status"] not in ("UNDETERMINABLE", None))
        correct_abst = sum(1 for tid in undet_ids
                           if data[tid]["prediction"]["predicted_status"] == "UNDETERMINABLE")
        correct_pos = sum(1 for tid in det_ids if data[tid]["prediction"]["full_correct"])
        tin = sum(r["input_tokens"] or 0 for r in recs)
        tout = sum(r["output_tokens"] or 0 for r in recs)
        entry = {
            "evidence_supported_accuracy": round(status_correct / n, 4),
            "full_answer_accuracy": round(full_correct / n, 4),
            "unsupported_positive_rate": round(unsup_pos / len(undet_ids), 4),
            "correct_abstention_rate": round(correct_abst / len(undet_ids), 4),
            "correct_positive_rate": round(correct_pos / len(det_ids), 4),
            "malformed": malformed,
            "input_tokens": tin, "output_tokens": tout,
            "cost_usd": round(tin / 1e6 * 2 + tout / 1e6 * 10, 4),
        }
        if c == "P2":
            pos = [r for r in recs if r.get("chain_valid") is not None]
            valid = sum(1 for r in pos if r["chain_valid"])
            entry["evidence_chain"] = {"positive_answers": len(pos), "valid": valid,
                                       "validity_rate": round(valid / len(pos), 4) if pos else None}
        per_cond[c] = entry

    # per-task change table P0 -> P1 -> P2
    changes = []
    for t in tasks:
        tid = t["task_id"]
        row = {"task_id": tid, "reference": refs[tid].status.value}
        for c in ("P0", "P1", "P2"):
            p = conds[c][tid]["prediction"]
            row[c] = "MALFORMED" if p["malformed"] else p["predicted_status"]
        det = refs[tid].status is not Label.UNDETERMINABLE
        row["regression"] = det and conds["P0"][tid]["prediction"]["full_correct"] and not (
            conds["P1"][tid]["prediction"]["full_correct"] and conds["P2"][tid]["prediction"]["full_correct"])
        changes.append(row)

    total_cost = round(sum(v["cost_usd"] for v in per_cond.values()), 4)
    summary = {"model": MODEL, "max_tokens": MAX_TOKENS, "n_tasks": len(tasks),
               "undeterminable_refs": len(undet_ids), "determinable_refs": len(det_ids),
               "per_condition": per_cond, "per_task_changes": changes, "total_cost_usd": total_cost}
    (OUT / "summary.json").write_text(json.dumps(summary, indent=2))
    print("\n=== SUMMARY ===")
    print(json.dumps({"per_condition": per_cond, "total_cost_usd": total_cost}, indent=2))


if __name__ == "__main__":
    run()
