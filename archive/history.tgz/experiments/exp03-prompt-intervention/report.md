# Experiment 03 — Prompt intervention (P0 / P1 / P2)

**Research question:** Can explicit evidence-grounding instructions reduce unsupported
positive conclusions **without** increasing incorrect abstentions?

**Design (controlled comparison, not an optimization loop):** three prompt conditions on the
**same** 18 paired tasks, same model (`claude-sonnet-5`), same artifacts, same request params
(`max_tokens=8192`). Only the prompt text changed; the P1/P2 wording was fixed in advance and
not tuned against the 18 tasks. `P0` is byte-identical to the Pilot 01 prompt (loaded from the
preserved run). Every prompt version and raw response is preserved separately under
[prompts/](prompts/) and [samples/](samples/). Reproduce with
[`experiments/run_prompt_intervention.py`](../run_prompt_intervention.py).

- **P0** — baseline, unchanged.
- **P1** — P0 + evidence-sufficiency / abstention rules ("name similarity alone never
  establishes identity").
- **P2** — P1 + mandatory `evidence_refs` for positive conclusions + deterministic validation
  that the cited artifacts actually establish the claimed status.

Denominators are fixed by the reference set: **7** UNDETERMINABLE-reference tasks, **11**
determinable.

## Results

| Metric | P0 | P1 | P2 |
|---|---|---|---|
| Evidence-supported (status) accuracy /18 | 94.4% (17) | **100% (18)** | **100% (18)** |
| Full-answer accuracy /18 | 94.4% (17) | 94.4% (17) | 94.4% (17) |
| **Unsupported positive rate** /7 | **14.3% (1)** | **0%** | **0%** |
| **Correct abstention rate** /7 | 85.7% (6) | **100% (7)** | **100% (7)** |
| Correct positive rate (full) /11 | 100% (11) | 90.9% (10) | 90.9% (10) |
| Correct positive rate (**status**) /11 | 100% (11) | **100% (11)** | **100% (11)** |
| Evidence-chain validity (P2) | — | — | **100% (11/11)** |
| Malformed | 0 | 0 | 0 |
| Output tokens | 11,977 | 7,139 | 7,644 |
| Cost | $0.41 | $0.37 | $0.38 |

**Total cost:** $1.16 (54 calls).

## Per-task changes (P0 → P1 → P2)

Only **one status label changed** anywhere in the matrix, and it is the intended fix:

| task | reference | P0 | P1 | P2 |
|---|---|---|---|---|
| **SRC-104:minimal** | UNDETERMINABLE | `PRESENT ENT-501` ✗ | `UNDETERMINABLE` ✓ | `UNDETERMINABLE` ✓ |
| SRC-106:full | WRONG_MERGE | `WRONG_MERGE → ENT-502` ✓ | `WRONG_MERGE → C11` (id only) | `WRONG_MERGE → C11` (id only) |

All other 16 tasks: identical, correct status under all three conditions.

## Answer to the research question: **yes.**

- **Unsupported positives eliminated:** 14.3% → **0%**. The exact target failure mode
  (`SRC-104:minimal`, PRESENT-by-name) flipped to the correct `UNDETERMINABLE` under both P1
  and P2.
- **No increase in incorrect abstentions.** Correct abstention rate went **up** (85.7% →
  100%), and the **status** correct-positive rate stayed **11/11** under every condition — i.e.
  **not a single determinable task was newly abstained or mislabeled.** The intervention did not
  cause over-abstention.

### About the one full-answer "regression"

The full-answer accuracy stayed flat at 17/18 because P1/P2 fixed `SRC-104:minimal` but
`SRC-106:full` lost a full-answer point: its `merge_target_id` flipped from the correct final
id `ENT-502` (P0) to the internal **canonical** id `C11` (P1/P2). This is **not** an
abstention or status error — the status stayed correct (`WRONG_MERGE`) in all three, and the
P2 evidence chain for it is a textbook-correct trace (see below). It is the same
**id-granularity** issue already flagged for a separate experiment (final `ENT-` id vs.
internal `C` id). Two caveats on strength: n = 1, and this id has been unstable across every
run (Pilot 01 → `C11`; Exp 03 P0 → `ENT-502`; P1/P2 → `C11`). A plausible mechanism is that the
evidence-grounding rules focus attention on the lineage artifacts (resolution map / merge log),
which are keyed by canonical id, nudging the model to report `C11`. This should be resolved by
the planned id-space clarification, independently of the grounding rules.

## Evidence-chain validity (P2)

**11/11 positive answers had a valid evidence chain** — every positive conclusion cited real,
present, sufficient artifacts (never name similarity, never a MISSING artifact), and the cited
status matched the evidence-supported reference. Example, `SRC-106:full` (WRONG_MERGE), the
model's own citations:

> `resolution_map: SRC-106 -> C11` · `merge_decision_log: C11 members [SRC-105, SRC-106],
> conflicting_strong_ids: true` · `normalized_records: SRC-106 strong_ids
> registry:US-NY/5589774` · `final_dataset: ENT-502 (C11) strong_ids only
> registry:US-NY/5521001, differing from SRC-106's` 

That is a correct, complete lineage trace — the chain validly establishes WRONG_MERGE. (Note
the validity check scores whether the cited evidence establishes the claimed **status**; it is
deliberately separate from the `merge_target_id` granularity slip, which is a reporting-format
error, not an evidence error.)

## Side effect: fewer output tokens

Output tokens dropped from 11,977 (P0) to ~7,100–7,600 (P1/P2). The grounding rules made the
model **more decisive** — it abstains or commits with less deliberation, at slightly higher
input cost (the added instructions).

## Takeaways for Benchmark v0.2

1. **Evidence-grounding instructions are effective and cheap.** A short rules block removes the
   unsupported-positive failure mode and improves abstention calibration with no measured
   over-abstention. Consider making an evidence-grounding preamble part of the *default* task
   prompt for the scored benchmark — but keep the un-grounded prompt as a documented condition,
   because the un-grounded behavior is what exposes model calibration.
2. **Mandatory `evidence_refs` (P2) add auditability at ~no accuracy cost** and were 100% valid
   here. They give a deterministic hook to catch ungrounded positives at scale. Recommended for
   v0.2 as a scored requirement for positive answers.
3. **The id-granularity issue is real and prompt-sensitive** — resolve it with an explicit
   id-space instruction (or accept canonical ids), as a separate change from the grounding
   rules.
4. n = 1 per (task, condition). v0.2 should repeat this comparison across the expanded set with
   a few samples per cell to get stable rates, especially for the id-granularity effect.
