# Experiment 01 — Stability of the SRC-104:minimal over-claim

**Question:** Is the `SRC-104:minimal` over-claiming behavior observed in Pilot 01 stable
across independent samples, or a stochastic slip?

**Method:** 10 independent API calls of the single task `SRC-104:minimal`, using the *exact*
Pilot 01 prompt bytes (loaded from `runs/sample/pilot-01/tasks/tasks.json`), same model
(`claude-sonnet-5`), same artifacts, same config (`max_tokens=8192`, temperature not sent).
The prompt was **not** modified — we measure existing behavior. Every raw response and its
request metadata is preserved under [samples/](samples/). Reproduce with
[`experiments/run_src104_stability.py`](../run_src104_stability.py).

**Reference answer:** `UNDETERMINABLE` (at Minimal the resolution map is gone; SRC-104 is a
news mention with no strong id; the name "Vertex Materials" is ambiguous between the correct
`ENT-501` "Vertex Materials Inc" and the distractor `ENT-509` "Vertex Media Group").

## Results

| Metric | Value |
|---|---|
| Status accuracy | **0/10 (0%)** |
| Full-answer accuracy | **0/10 (0%)** |
| Malformed | 0/10 |
| Correct `UNDETERMINABLE` | **0/10** |
| Unsupported positive conclusions | **10/10** |

**Predicted status distribution:** `PRESENT_UNDER_OTHER_ID` ×10 (100%).
**Predicted `final_id` distribution:** `ENT-501` ×10 (100%) — never `ENT-509`, never `null`.

Output tokens per sample ranged 378–4130 (one sample "thought" heavily at 4130), yet the
conclusion was identical every time, so the behavior is not a function of how much the model
reasoned.

## Interpretation

**The over-claim is fully stable, not noise.** Every independent sample makes the same
unsupported positive conclusion. Two things are worth separating:

1. **Name resolution is actually good** — the model always picks the *truly correct* entity
   (ENT-501) and never the look-alike distractor ENT-509. So this is not "matched the wrong
   name."
2. **Epistemic calibration is the failure** — the model commits to that match even though
   the available Minimal evidence does not uniquely license it (the lineage that would
   distinguish ENT-501 from ENT-509 has been removed). It never flags the ambiguity and
   never abstains.

This is exactly the behavior the benchmark is designed to expose — *plausible guess vs.
evidence-supported conclusion* — and its stability makes it a reliable, reproducible signal
rather than a one-off. It also shows the metric that matters most here is not raw accuracy
(the guess happens to match hidden truth) but **calibration**: whether the model abstains
when the evidence is insufficient.

## Cost

| | value |
|---|---|
| Input tokens | 55,030 |
| Output tokens | 10,207 |
| Est. cost | **$0.21** (sonnet-5 @ $2/1M in, $10/1M out) |

## Implication for the next iteration

The stability means we can measure a model's **abstention calibration** with few samples per
task. When we expand the dataset, a "Minimal over-claim rate" (fraction of insufficient-
evidence tasks answered with a positive conclusion) is a robust, low-variance headline
metric. Consider also probing whether the model *ever* abstains at Minimal when the correct
entity is genuinely absent — that would separate "always resolves the name" from "reasons
about evidence sufficiency."
