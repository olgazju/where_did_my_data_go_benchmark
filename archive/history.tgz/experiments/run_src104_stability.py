"""Experiment 01 — is the SRC-104:minimal over-claim stable across independent samples?

Draws N independent samples of the SINGLE task SRC-104:minimal using the exact same model,
prompt, artifacts, and configuration as Pilot 01 (the prompt bytes are loaded verbatim from
the preserved Pilot 01 run). We are MEASURING existing behavior, not optimizing it — the
prompt is never modified.

Each raw response + request metadata is preserved under experiments/exp01-src104-minimal/.
The script is resumable: samples already on disk are not re-called.

Usage:
    ANTHROPIC_API_KEY=... uv run --locked python experiments/run_src104_stability.py [N]
"""

from __future__ import annotations

import hashlib
import json
import sys
from collections import Counter
from pathlib import Path

from poc.evaluator import evaluate_one
from poc.models import Label, Observability, ReferenceAnswer
from poc.provider.anthropic import AnthropicProvider
from poc.provider.base import LLMRequest

REPO = Path(__file__).resolve().parents[1]
PILOT = REPO / "runs" / "sample" / "pilot-01"
OUT = REPO / "experiments" / "exp01-src104-minimal"
TASK_ID = "SRC-104:minimal"
MODEL = "claude-sonnet-5"
MAX_TOKENS = 8192
TEMPERATURE = 0.0


def _load_prompt_and_reference() -> tuple[str, ReferenceAnswer]:
    tasks = {t["task_id"]: t for t in json.loads((PILOT / "tasks" / "tasks.json").read_text())}
    refs = json.loads((PILOT / "tasks" / "references.json").read_text())
    return tasks[TASK_ID]["prompt"], ReferenceAnswer.model_validate(refs[TASK_ID])


def _fingerprint(prompt: str) -> dict:
    return {
        "requested_model": MODEL, "provider": "anthropic",
        "max_tokens": MAX_TOKENS, "temperature": TEMPERATURE,
        "prompt_sha256": hashlib.sha256(prompt.encode()).hexdigest(),
    }


def main(n: int) -> None:
    prompt, reference = _load_prompt_and_reference()
    assert reference.status is Label.UNDETERMINABLE, reference.status
    (OUT / "samples").mkdir(parents=True, exist_ok=True)

    provider = AnthropicProvider(model=MODEL)
    pending = [i for i in range(1, n + 1) if not (OUT / "samples" / f"{i:02d}.json").exists()]
    if pending:
        provider.preflight()
    print(f"prompt_sha256={_fingerprint(prompt)['prompt_sha256'][:12]}  pending={pending}")

    for i in range(1, n + 1):
        path = OUT / "samples" / f"{i:02d}.json"
        if path.exists():
            continue
        req = LLMRequest(model=MODEL, max_tokens=MAX_TOKENS, temperature=TEMPERATURE, prompt=prompt)
        resp = provider.complete(req)
        rec = evaluate_one(f"{TASK_ID}#s{i}", reference, resp.text)
        path.write_text(json.dumps({
            "sample": i,
            "task_id": TASK_ID,
            "model_requested": MODEL,
            "model_returned": resp.model,
            "request_params": resp.request_params,
            "fingerprint": _fingerprint(prompt),
            "text": resp.text,
            "input_tokens": resp.input_tokens,
            "output_tokens": resp.output_tokens,
            "prediction": rec.model_dump(mode="json"),
            "raw": resp.raw,
        }, indent=2, default=str))
        p = rec
        print(f"  sample {i:02d}: status={p.predicted_status} malformed={p.malformed} "
              f"full_correct={p.full_correct} out_tok={resp.output_tokens}")

    _summarize(n, reference)


def _summarize(n: int, reference: ReferenceAnswer) -> None:
    samples = [json.loads(p.read_text()) for p in sorted((OUT / "samples").glob("*.json"))]
    status = [s["prediction"]["predicted_status"] for s in samples]
    status_correct = sum(s["prediction"]["status_correct"] for s in samples)
    full_correct = sum(s["prediction"]["full_correct"] for s in samples)
    malformed = sum(s["prediction"]["malformed"] for s in samples)
    undeterminable = sum(1 for st in status if st == "UNDETERMINABLE")
    unsupported_positive = sum(
        1 for st in status if st not in ("UNDETERMINABLE", None)
    )
    final_ids = Counter(
        json.loads(s["text"][s["text"].find("{"): s["text"].rfind("}") + 1]).get("final_id")
        if "{" in s["text"] else "<no-json>"
        for s in samples
    )
    tin = sum(s["input_tokens"] or 0 for s in samples)
    tout = sum(s["output_tokens"] or 0 for s in samples)
    cost = tin / 1e6 * 2 + tout / 1e6 * 10  # sonnet-5 pricing

    summary = {
        "task_id": TASK_ID,
        "model": MODEL,
        "max_tokens": MAX_TOKENS,
        "reference_status": reference.status.value,
        "n_samples": len(samples),
        "status_accuracy": round(status_correct / len(samples), 4),
        "full_accuracy": round(full_correct / len(samples), 4),
        "malformed": malformed,
        "correct_undeterminable": undeterminable,
        "unsupported_positive_conclusions": unsupported_positive,
        "predicted_status_distribution": dict(Counter(status)),
        "predicted_final_id_distribution": {str(k): v for k, v in final_ids.items()},
        "input_tokens": tin,
        "output_tokens": tout,
        "est_cost_usd": round(cost, 4),
        "pricing": "sonnet-5 $2/M in, $10/M out",
    }
    (OUT / "summary.json").write_text(json.dumps(summary, indent=2))
    print("\n=== SUMMARY ===")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main(int(sys.argv[1]) if len(sys.argv) > 1 else 10)
