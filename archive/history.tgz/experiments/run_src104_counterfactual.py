"""Experiment 02 — controlled counterfactual: evidence-supported identity vs. plausible
name resolution for SRC-104.

Three variants (same underlying record, SRC-104 "Vertex Materials", a news mention):

  A. TRUE match  — SRC-104 really is ENT-501, but the Minimal evidence is insufficient.
  B. FALSE match — SRC-104's true entity is a DISTINCT entity that is ABSENT from final,
                   while ENT-501 remains a plausible name match.
  C. VERIFIED    — one decisive observable artifact (resolution_map: SRC-104 -> C10) is
                   restored, which establishes SRC-104 -> ENT-501.

Crucial design point: **A and B are observationally identical** — only the hidden ground
truth differs, which does not appear in the prompt. So A and B share ONE observable
condition ("AB"); we draw 10 samples of it and score them under both hidden-truth framings.
C is a second distinct observable condition; 10 samples. Same model/config as Experiment 01.

Expected (evidence-supported) answers: AB -> UNDETERMINABLE, C -> PRESENT_UNDER_OTHER_ID
(ENT-501).

The purpose is to test whether the model distinguishes plausible entity resolution from
evidence-supported identity — not merely whether it selects the correct hidden entity.

Usage:
    ANTHROPIC_API_KEY=... uv run --locked python experiments/run_src104_counterfactual.py [N]
"""

from __future__ import annotations

import copy
import hashlib
import json
import sys
from collections import Counter
from pathlib import Path

from poc.evaluator import evaluate_one
from poc.models import Artifact, ArtifactState, Label, Observability, ReferenceAnswer
from poc.observability import build_bundle
from poc.prompts import render_prompt
from poc.provider.anthropic import AnthropicProvider
from poc.provider.base import LLMRequest
from poc.simulator import simulate

REPO = Path(__file__).resolve().parents[1]
OUT = REPO / "experiments" / "exp02-src104-counterfactual"
MODEL = "claude-sonnet-5"
MAX_TOKENS = 8192
TEMPERATURE = 0.0


def build_conditions():
    """Return {condition: (prompt, reference)}. AB is shared by variants A and B."""
    sim = simulate()
    ab_bundle = build_bundle(sim, Observability.MINIMAL)  # no lineage; ambiguous name
    c_bundle = copy.deepcopy(ab_bundle)
    # C restores exactly ONE decisive artifact establishing SRC-104 -> C10 (-> ENT-501).
    c_bundle.artifacts["resolution_map"] = Artifact(
        name="resolution_map", state=ArtifactState.COMPLETE, complete_scopes=["resolution"],
        rows=[{"source_id": "SRC-104", "canonical_id": "C10"}],
    )
    ab_ref = ReferenceAnswer(source_id="SRC-104", level=Observability.MINIMAL, status=Label.UNDETERMINABLE)
    c_ref = ReferenceAnswer(source_id="SRC-104", level=Observability.MINIMAL,
                            status=Label.PRESENT_UNDER_OTHER_ID, final_id="ENT-501")
    return {
        "AB": (render_prompt(ab_bundle, "SRC-104"), ab_ref),
        "C": (render_prompt(c_bundle, "SRC-104"), c_ref),
    }


def _fingerprint(prompt: str) -> dict:
    return {"requested_model": MODEL, "provider": "anthropic", "max_tokens": MAX_TOKENS,
            "temperature": TEMPERATURE, "prompt_sha256": hashlib.sha256(prompt.encode()).hexdigest()}


def _final_id(text: str):
    if "{" not in text:
        return "<no-json>"
    try:
        return json.loads(text[text.find("{"): text.rfind("}") + 1]).get("final_id")
    except Exception:  # noqa: BLE001
        return "<parse-error>"


def run(n: int) -> None:
    conditions = build_conditions()
    (OUT / "prompts").mkdir(parents=True, exist_ok=True)
    for cond, (prompt, _) in conditions.items():
        (OUT / "prompts" / f"{cond}.txt").write_text(prompt)

    provider = AnthropicProvider(model=MODEL)
    need = any(
        not (OUT / "samples" / cond / f"{i:02d}.json").exists()
        for cond in conditions for i in range(1, n + 1)
    )
    if need:
        provider.preflight()

    for cond, (prompt, reference) in conditions.items():
        (OUT / "samples" / cond).mkdir(parents=True, exist_ok=True)
        print(f"[{cond}] prompt_sha256={_fingerprint(prompt)['prompt_sha256'][:12]}")
        for i in range(1, n + 1):
            path = OUT / "samples" / cond / f"{i:02d}.json"
            if path.exists():
                continue
            resp = provider.complete(LLMRequest(model=MODEL, max_tokens=MAX_TOKENS,
                                                 temperature=TEMPERATURE, prompt=prompt))
            rec = evaluate_one(f"{cond}#s{i}", reference, resp.text)
            path.write_text(json.dumps({
                "condition": cond, "sample": i, "model_requested": MODEL, "model_returned": resp.model,
                "request_params": resp.request_params, "fingerprint": _fingerprint(prompt),
                "text": resp.text, "input_tokens": resp.input_tokens, "output_tokens": resp.output_tokens,
                "prediction": rec.model_dump(mode="json"), "raw": resp.raw,
            }, indent=2, default=str))
            print(f"  {cond} {i:02d}: status={rec.predicted_status} full_correct={rec.full_correct} "
                  f"final_id={_final_id(resp.text)} out_tok={resp.output_tokens}")

    summarize(n)


def _load(cond: str):
    return [json.loads(p.read_text()) for p in sorted((OUT / "samples" / cond).glob("*.json"))]


def _cond_stats(samples: list[dict]) -> dict:
    status = [s["prediction"]["predicted_status"] for s in samples]
    finals = Counter(_final_id(s["text"]) for s in samples)
    positives = [st for st in status if st not in ("UNDETERMINABLE", None)]
    return {
        "n": len(samples),
        "status_distribution": dict(Counter(status)),
        "final_id_distribution": {str(k): v for k, v in finals.items()},
        "positive_rate": round(len(positives) / len(samples), 4) if samples else 0.0,
        "abstention_rate": round(sum(st == "UNDETERMINABLE" for st in status) / len(samples), 4) if samples else 0.0,
        "present_ent501": sum(1 for s in samples
                              if s["prediction"]["predicted_status"] == "PRESENT_UNDER_OTHER_ID"
                              and _final_id(s["text"]) == "ENT-501"),
        "malformed": sum(s["prediction"]["malformed"] for s in samples),
        "in_tok": sum(s["input_tokens"] or 0 for s in samples),
        "out_tok": sum(s["output_tokens"] or 0 for s in samples),
    }


def summarize(n: int) -> None:
    ab, c = _cond_stats(_load("AB")), _cond_stats(_load("C"))
    tin, tout = ab["in_tok"] + c["in_tok"], ab["out_tok"] + c["out_tok"]
    cost = tin / 1e6 * 2 + tout / 1e6 * 10

    summary = {
        "model": MODEL, "max_tokens": MAX_TOKENS, "n_per_condition": n,
        "conditions": {
            "AB_shared_observable": {
                "expected": "UNDETERMINABLE",
                **ab,
                "unsupported_positive_rate": ab["positive_rate"],
                "correct_abstention_rate": ab["abstention_rate"],
            },
            "C_verified": {
                "expected": "PRESENT_UNDER_OTHER_ID(ENT-501)",
                **c,
                "correct_present_rate": round(c["present_ent501"] / c["n"], 4) if c["n"] else 0.0,
            },
        },
        # Interpretation under the two hidden-truth framings (identical prompt, identical samples):
        "variant_A_true_match": {
            "hidden_truth": "SRC-104 really is ENT-501 (present)",
            "unsupported_positive_rate": ab["positive_rate"],
            "correct_abstention_rate": ab["abstention_rate"],
        },
        "variant_B_false_match": {
            "hidden_truth": "SRC-104's true entity is distinct and ABSENT from final",
            "unsupported_positive_rate": ab["positive_rate"],
            "factually_wrong_present_ent501": ab["present_ent501"],  # PRESENT here contradicts hidden truth
            "correct_abstention_rate": ab["abstention_rate"],
        },
        "evidence_sensitivity": {
            "present_rate_AB": ab["positive_rate"],
            "present_rate_C": c["positive_rate"],
            "delta_present_rate_C_minus_AB": round(c["positive_rate"] - ab["positive_rate"], 4),
            "abstention_shift_AB_to_C": round(ab["abstention_rate"] - c["abstention_rate"], 4),
            "note": "If PRESENT rate is ~equal in AB and C, the model is NOT evidence-sensitive: "
                    "it asserts identity regardless of whether the observable evidence supports it.",
        },
        "cost_usd": round(cost, 4),
        "input_tokens": tin, "output_tokens": tout, "pricing": "sonnet-5 $2/M in, $10/M out",
    }
    (OUT / "summary.json").write_text(json.dumps(summary, indent=2))
    print("\n=== SUMMARY ===")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    run(int(sys.argv[1]) if len(sys.argv) > 1 else 10)
