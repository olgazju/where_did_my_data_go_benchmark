# Experiment 02 — Evidence-supported identity vs. plausible resolution (SRC-104)

**Question:** Does the model distinguish *evidence-supported identity* from *plausible name
resolution* — or does it assert an identity whenever a plausible name match exists,
regardless of whether the observable evidence licenses it?

**Design — controlled counterfactual, three variants of SRC-104 ("Vertex Materials", a news
mention with no strong id):**

| Variant | Hidden truth | Observable evidence | Expected (evidence-supported) |
|---|---|---|---|
| **A** True match | SRC-104 really is ENT-501 | Minimal (no lineage; name ambiguous vs. distractor ENT-509 "Vertex Media Group") | UNDETERMINABLE |
| **B** False match | SRC-104's true entity is distinct and **absent** from final | **identical to A** | UNDETERMINABLE |
| **C** Verified | (n/a) | Minimal **+ one decisive artifact**: `resolution_map: SRC-104 → C10` | PRESENT → ENT-501 |

A and B are **observationally identical** — only hidden ground truth changes, which never
appears in the prompt — so they share one observable condition ("AB"). Prompt integrity was
verified by hash: `AB` = `bb9e0fea71e3…`, `C` = `90beb886eb78…` (C differs from AB by exactly
the added `resolution_map` artifact). 10 samples per observable condition,
`claude-sonnet-5`, `max_tokens=8192`, same config as Experiment 01. Prompt not tuned. Raw
responses + request metadata under [samples/](samples/); prompts under [prompts/](prompts/).
Reproduce with [`experiments/run_src104_counterfactual.py`](../run_src104_counterfactual.py).

## Results

| Condition | Expected | PRESENT→ENT-501 | UNDETERMINABLE | Unsupported positive | Correct |
|---|---|---|---|---|---|
| **AB** (no lineage) | UNDETERMINABLE | **10/10** | 0/10 | **100%** | 0/10 |
| **C** (decisive mapping added) | PRESENT ENT-501 | **10/10** | 0/10 | — | **10/10** |

**Evidence sensitivity:** PRESENT-rate(AB) = 1.0, PRESENT-rate(C) = 1.0 →
**Δ = 0.0**. Abstention shift AB→C = 0.0.

Interpretation under the two hidden-truth framings (same prompt, same 10 samples):

| Framing | Model output | Verdict |
|---|---|---|
| **A** (SRC-104 truly is ENT-501) | PRESENT ENT-501 ×10 | unsupported, but *accidentally* matches hidden truth |
| **B** (SRC-104's true entity is absent) | PRESENT ENT-501 ×10 | **unsupported AND factually wrong ×10** |

## Interpretation

**The model does not distinguish evidence-supported identity from plausible resolution.**
It emits the *identical* confident `PRESENT → ENT-501` in AB (where the evidence does not
license it) and in C (where it does). Adding the one decisive artifact changed nothing about
the answer — because the model was already asserting the identity without it. Evidence
sensitivity is **zero** on this task.

Two conclusions the counterfactual makes airtight, which raw accuracy could not:

1. **The model is not "reading the evidence" for identity.** In Experiment 01 one could
   argue the model inferred ENT-501 from something subtle. Variant B rules that out: with a
   byte-identical prompt, the correct answer is still UNDETERMINABLE and the true entity is
   *absent*, yet the model asserts ENT-501 just as confidently. Its "correctness" in
   Variant A is a coincidence of hidden truth, not evidence use.
2. **The model is capable, but mis-calibrated.** Variant C shows the model produces the
   right answer (10/10) once the establishing artifact is present — and with far less
   deliberation (avg ≈316 output tokens in C vs ≈744 in AB). So the failure is not
   inability; it is over-confidence when the establishing evidence is absent. More thinking
   in AB did not produce abstention.

This is precisely the distinction the benchmark exists to measure. The right headline metric
is **abstention calibration** — here, a **0% correct-abstention rate** on an
insufficient-evidence task, versus **100% correct** when the evidence is restored.

## Token usage & cost

| | Input | Output | Cost |
|---|---|---|---|
| AB (10) | 55,030 | 7,438 | — |
| C (10) | 55,990 | 3,163 | — |
| **Total (20 samples)** | **111,020** | **10,601** | **$0.33** (sonnet-5 $2/M in, $10/M out) |

## Implications for the next iteration

- **Score calibration, not just accuracy.** A model that name-resolves well but never
  abstains will look accurate wherever the plausible match coincides with hidden truth
  (Variant A) and fail silently wherever it does not (Variant B). Only the counterfactual
  exposes it. Build B-style *false-match* items (plausible name present, true entity absent)
  into the expanded benchmark as the primary calibration probe.
- **Report an "unsupported-positive rate"** on insufficient-evidence tasks as a headline,
  alongside the C-style positive control that confirms the model *can* answer when evidence
  exists.
- One caveat: n=10 on one record. The effect is unambiguous here (10/10 vs 10/10, Δ=0), but
  the expanded set should spread this across several records and name-similarity strengths.
